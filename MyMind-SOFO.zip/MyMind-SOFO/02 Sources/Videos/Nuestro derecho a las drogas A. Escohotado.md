---
created: 2025-08-11
tags:
  - Drogas
  - filosofía
  - Libertad
aliases: 
Url: https://www.youtube.com/watch?v=K5g7-jSVRZY&t=472s
---
Charla de [[Antonio Escohotado]]
- Nuestro derecho a las [[Drogas]] no es otra cosa que nuestro derecho a ser libres