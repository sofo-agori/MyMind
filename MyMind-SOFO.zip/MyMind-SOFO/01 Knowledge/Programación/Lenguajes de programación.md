---
created: 2025-08-25
tags: []
Image:
Url:
---
Estos son los lenguajes que me interesan aprender
- Phyton
- Javascript
	- ThreeJS
	- 
- SQL