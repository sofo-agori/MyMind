---
tags:
  - 3D
  - Blender
master folder: "[[Blender]]"
---

Render Region: **Ctrl + B**
