---
tags:
  - aftereffects
  - efecto
master folder: "[[Efectos]]"
---
![[Tracking box AE.jpg]]

[motion tracking box | after effects tutorial](https://youtu.be/yh9l7xzWImU)
