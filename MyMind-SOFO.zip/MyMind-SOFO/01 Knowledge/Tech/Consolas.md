## Links:

- [Retroid Pocket Mini V2 Handheld](https://www.goretroid.com/collections/frontpage/products/retroid-pocket-mini-v2-handheld) Siempre me han gustado la marca Retroid.
- [ 8Bitdo Ultimate 2C Wired Controller for Windows](https://a.co/d/gxKClQg) - Control para jugar que me encanta.
- 
