---
status: Por leer
tags:
  - Libro
  - Creatividad
  - Conocimiento
Autor: Max Bennett
Image: https://m.media-amazon.com/images/I/81xA5147ATL._UF1000,1000_QL80_.jpg
master folder: "[[Por leer]]"
---
