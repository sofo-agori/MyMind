
- El eco-brutalismo es un movimiento arquitectónico que combina la estética cruda del brutalismo tradicional con elementos de "sostenibilidad" y naturaleza. Me fascina la tensión visual entre el hormigón duro y la vegetación orgánica. Y ese contraste de colores que da el verde y el gris.

- Me llama la atención que muchos proyectos de eco-brutalismo están en el Latinoamérica, especialmente en climas tropicales donde la integración con la naturaleza es más natural y funcional.

- Hay una paradoja inherente: usar hormigón (uno de los materiales más contaminantes) y llamarlo "eco". Sin embargo, algunos proyectos genuinamente integran tecnologías sostenibles más allá de solo agregar plantas.

| Mi estructura favorita es sin duda<br>el teatro Teresa Carreño, ubicado<br>en mi país Venezuela. Este teatro<br>tiene una conexión directa con el<br>parque los Caobos, llevando así su conexión con la naturaleza a un nivel más lógico. | ![[Teatro-Teresa-Carren~o_DF-64-DESTACADA 1.jpg]] |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------- |

- El eco-brutalismo puede ser imponente y bonito estéticamente, pero en muchas ocasiones puede significar abandono.

## Personas 

- Tomas Lugo - Arquitecto del Teresa Carreño [Arquitecto Tomas Antonio Lugo Marcano](https://entrerayas.com/arquitecto-tomas-antonio-lugo-marcano/)

## Notas 

- El eco-brutalismo refleja el creciente deseo de combinar forma y función de un modo que esté en armonía con el medio ambiente, transformando los espacios urbanos en lugares más habitables y ecoeficientes. - [A Fusion of Concrete and Greenery with Eco-Brutalism](https://thursd.com/articles/eco-brutalism-with-plants)

- Me gusta la idea. Su fantasía es genial, pero la realidad es que hay arañas, insectos, moho y raíces dañadas. [what are y’all’s thoughts on ecobrutalism? : r/solarpunk](https://www.reddit.com/r/solarpunk/comments/yl3cqo/comment/iuye663/?utm_source=share&utm_medium=web3x&utm_name=web3xcss&utm_term=1)
## Conexiones y analogías

- El eco-brutalismo me recuerda a varios videojuegos o series que me han gustado. Fallout, Wolfenstein, Halo (Uno de los primero juegos que tuve la oportunidad de jugar). Esa forma en la que la naturaleza reclama los espacio donde alguna vez estuvo, me parece increíble. 

- La tensión entre lo crudo y lo orgánico es similar a mi gustos. Esa constante "pelea interna": Lo clásico o lo moderno, las pantallas o el papel, las peliculas de acción o de comedia, etc. Pero lo que lleva al final a dos cosas antagónicas que sobreviven juntas.

- Es como si el hormigón fuera el lienzo en blanco y la vegetación el elemento que le da vida y contexto emocional.


## Enlaces similares

- [[Brutalismo ]]
- [[Sostenibilidad en arquitectura]]
- [[Materiales de construcción eco-friendly]]
- [[Arquitectura biofílica]]
- [[Greenwashing en diseño]]
- [[Arquitectura tropical]]
- [[Jardines verticales]]
- [[Arquitectura solarpunk]]

## Etiquetas

#eco-brutalismo #arquitectura #sostenibilidad #brutalismo #diseño #hormigón #naturaleza #tendencias #greenwashing #biofilia
