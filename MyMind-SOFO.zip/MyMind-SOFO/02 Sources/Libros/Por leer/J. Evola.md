---
status: Por leer
tags:
  - Libro
  - filosofía
Autor: J. Evola
master folder: "[[Por leer]]"
Image: https://m.media-amazon.com/images/I/61t-cgTmWvL._UF1000,1000_QL80_.jpg
---
