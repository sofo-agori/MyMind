---
created: 2025-08-09
tags:
  - Personal
  - Tops
aliases:
---
## Reales
- Renny Otolina
- [[Leonardo da Vinci]]
- Kanye West
- Ernest Junger
- Carl Sagan

## Ficticios:
- Kaneda, Akira.
- Rustin Cohle, True detective
- Mike Ehrmantraut, Breaking Bad
- El Anarca, de Eumeswill, libro de Junger.
- Máximo Meridio, Gladiator. 
- The Punisher
- Daredevil