---
created: <% tp.date.now("YYYY-MM-DD") %>
tags: []
Image:
Url:
master folder:
---
## Notas:
- [“Los curadores de contenido son los nuevos superhéroes de la web".](https://about.linxpy.com/)

## Links:
[Linxpy.](https://about.linxpy.com/) -Simbiosis hombre-máquina para marcadores profesionales seleccionados.
