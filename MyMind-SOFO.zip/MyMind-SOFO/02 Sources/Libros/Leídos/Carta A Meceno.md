---
tags:
  - Libro
  - filosofía
status: "[[!Leídos]]"
Autor: Epícuro
Image: https://m.media-amazon.com/images/I/71t1RLCzJxL._UF1000,1000_QL80_.jpg
master folder: "[[Leídos]]"
---
> [!NOTE]
> 	La muerte no es para nosotros el mas temible de los males porque, cuando nosotros somos, la muerte no esta, y, cuando la muerte esta, entonces nosotros ya no somos; no lo es ni para los vivos, pues, ni para los muertos: para los  unos justo porque, para elfos, no es, y para los otros porque ellos ya no son.  Pero la mayoría de los hombres ora huyen de la muerte como del mayor mal,  ora la buscan como descanso de los males de la vida.
> 
> ---
> 
> 	El sabio, por su parte, no desdeña vivir pero tampoco teme no vivir, porque  ni tiene nada contra la vida ni cree que haya nada malo en no vivir. Del modo  como, al corner, no busca la abundancia, sino la exquisitez, así quiere sacarle su  fruto al tiempo, no abundante, sino exquisito.
> 	
> ---
> 	
> 	Cierto que todo placer es, por naturaleza, un bien en sí mismo, y, sin emliargo, no todo placer ha de tomarse; de modo similar, todo dolor es un mal, pero no siempre han de evitarse todos.
> 	
> ---
> 	
> 	El pan y el agua proporcionan el mas alto placer, cuando uno tiene real necesidad de ellos.
> 	

#epicureísmo #filosofía 