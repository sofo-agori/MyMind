---
status: Por leer
tags:
  - Libro
  - Historia
Autor: Santiago Castellanos
Image: https://m.media-amazon.com/images/I/41IMiYjadyL._SY445_SX342_.jpg
master folder: "[[Por leer]]"
---
