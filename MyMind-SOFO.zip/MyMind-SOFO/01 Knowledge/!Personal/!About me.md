---
created: 2025-08-22
tags: []
Image:
Url:
---
Hijo de mi madre, nieto de mi abuela, hermano de mi hermano, novio de mi novia, todo esto es lo que soy, lo demás son añadiduras y simples idas y venidas de esta vida. Somos cambiantes, lo que está escrito acá no tiene porque ser lo que soy el día de mañana.

Soy un tipo curioso. Muy curioso. Desde pequeño mi palabra más usada era "por qué". Mi mayor meta en esta vida es aprender el mayor número de cosas. Sobretodo habilidades digitales. Soy un apasionado de la cultura general y un friki del internet.

Para mi el internet fue, es y será mi mayor maestro. Tener toda la información a un solo click me parece sin duda el mejor invento de la historia. Internet para mi es más que una herramienta: es mi ideal. El ideal de la libertad, de la información libre. No me gusta la censura y odio como el copyright nos ha quitado la red sin cadenas.

Por otro lado, soy católico ferviente, creo en Dios, en un Dios bondadoso. Canalizo mi humildad ante Él. No me arrodillo ante más nadie que no sea Él.

Los políticos y poderosos me causan lástima y repulsión. No los odio, eso no me haría anarca, simplemente los veo por debajo del hombro. Solo son pobres hombres que dedican su vida a adormecer otros hombres.

Estoy interesado en muchas áreas del saber, por eso decidí construir este espacioen el que mi idea es bajar toda la info que consigo en Internet y tener condensado todo de una mejor manera. Es mi libro común.

# Mis ideales:
- [[Anarca]]
- Agorismo
- Anarquismo cristiano
- [[Barrani]]

# Áreas de interés
- Arquitectura
- Internet
- Filosofía
- Tecnología
- Música
- Arte

# Habilidades personales
•Diseño
•Audiovisual
•Fotografía
•Marketing
•Motion Graphics
•3D
•Marketing