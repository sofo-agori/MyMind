---
created: 2025-08-26
tags:
  - tipografía
  - diseño
  - articulo
Image:
Url: https://meetchopz.medium.com/10-bad-typography-habits-that-scream-amateur-8bac07f9c041
master folder: "[[TIpografía]]"
---

## El texto centrado:
![[Texto alineado.gif]]
Dificulta la vista del usuario, no tienen a donde dirigir la vista cuando terminan una linea. 

## Demasiado o poco interlineado
![[Demasiado o poco interlineado.gif]]
Lo mejor es usar el 150% del texto (interlineado)

## Demasiadas Mayúsculas:
Cuando en un texto hay demasiadas mayúsculas se dificulta la lectura.
## El uso de hyphenate
No dividir los textos con "'-". 

## Mala justificación
![[Mala justificación.gif]]
Lo contrario a lo que se cree: líneas de texto desiguales facilitan la lectura de las personas. 

## Divide bloques de texto como puedas
![[Divide bloques de texto como puedas.gif]]
Esto facilita la lectura

## Tamaño de la linea
![[Tamaño de la linea.gif]]
Mientras más larga es una linea de texto, mas difícil es de leer.  Un buen rango de longitud de línea es entre 45 y 75 caracteres (66 incluidos los espacios).

