---
created: 2025-08-26
tags:
  - filosofía
  - Política
Image:
Url:
master folder:
---
## Notes:
- [Bogotaensis en X: "«Yo soy en el espacio anarca, en el tiempo metahistórico. Por eso, no me siento ligado ni al presente político ni a la tradición; soy una hoja en blanco, abierta y capacitada hacia todas las direcciones». 27 años sin Jünger.](https://x.com/Bogotaensis/status/1891518558489686459)