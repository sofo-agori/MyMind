---
created: 2025-08-26
tags:
  - Blender
  - Addons
Image: "[[Quick Menu.png]]"
Url: https://github.com/passivestar/quickmenu
master folder: "[[Blender-Addons]]"
---
![[Quick Menu.png]]