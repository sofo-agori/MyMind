---
created: 2025-08-26
tags: []
Image:
Url:
master folder:
---
## Links:
- [A Primer on Lens Equivalence : r/M43](https://www.reddit.com/r/M43/comments/102jngq/a_primer_on_lens_equivalence/)