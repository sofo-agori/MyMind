---
tags:
  - 3D
  - Blender
master folder: "[[Blender]]"
---
## Roughness
**Roughness** significa **rugosidad** y se refiere a qué tan suave o rugosa es la superficie de un material, especialmente en el contexto de materiales PBR (Physically Based Rendering) en 3D. Este parámetro controla **cómo se refleja la luz en la superficie**:

- **Valores bajos de roughness (cercanos a 0 o negro en un mapa de texturas):** la superficie es muy lisa, los reflejos son nítidos y definidos, como en un espejo o una superficie muy pulida[3](https://learn.microsoft.com/es-es/azure/remote-rendering/overview/features/pbr-materials)[4](https://www.reddit.com/r/3Dmodeling/comments/198kpd8/can_someone_explain_to_me_how_roughness_maps_work/?tl=es-419).
    
- **Valores altos de roughness (cercanos a 1 o blanco en el mapa):** la superficie es más áspera o mate, los reflejos son borrosos o casi inexistentes, como en un papel o una roca[1](https://www.texturas3d.com/fotogrametria/texturas-pbr/)[2](https://lumion.es/materiales-pbr/)[3](https://learn.microsoft.com/es-es/azure/remote-rendering/overview/features/pbr-materials).
    

En la práctica, el mapa de roughness puede incluir detalles como **arañazos, polvo, desgaste y variaciones microscópicas** que afectan el realismo del material final[1](https://www.texturas3d.com/fotogrametria/texturas-pbr/)[2](https://lumion.es/materiales-pbr/)[6](http://forum.accasoftware.com/es/edificius/id90959/los-mapas-texturas-a-utilizar-para-la-creacion-del-material.html).

**Resumiendo:**  
El parámetro roughness determina cuánto se dispersa la luz sobre la superficie: a menor roughness, reflejos más limpios; a mayor roughness, reflejos más difusos y borrosos[3](https://learn.microsoft.com/es-es/azure/remote-rendering/overview/features/pbr-materials)[1](https://www.texturas3d.com/fotogrametria/texturas-pbr/).


## IOR
**IOR** significa **Índice de Refracción** (del inglés _Index of Refraction_). En el shader **Principled BSDF** de Blender, el parámetro IOR es fundamental para definir cómo se comporta la luz al interactuar con materiales transparentes, translúcidos o reflectantes.

 ¿Para qué sirve el IOR en Principled BSDF?

- **Determina la cantidad de refracción:**  
    El IOR controla cuánto se desvía la luz al entrar o salir del material. Un valor IOR bajo (como 1.0) simula materiales que apenas desvían la luz (ejemplo: el aire). Valores más altos simulan materiales como vidrio, plástico, agua o gemas, que sí refractan la luz visiblemente.
    
- **Afecta los reflejos (efecto Fresnel):**  
    El IOR también influye en la intensidad de los reflejos en ángulos bajos. Valores altos aumentan el efecto de borde, típico de materiales brillantes y pulidos.
    

 Ejemplos de valores típicos de IOR

|Material|Valor IOR aproximado|
|---|---|
|Aire|1.0003|
|Agua|1.33|
|Vidrio común|1.45 – 1.54|
|Acrílico|~1.49|
|Diamante|2.42|

Práctico en el flujo de trabajo creativo

En el **Principled BSDF**, al aumentar el IOR:

- Un material se ve más como cristal, plástico pulido o piedra preciosa.
    
- Los reflejos se vuelven más intensos y evidentes, sobre todo hacia los bordes del objeto.
    
- En materiales donde el parámetro **Transmission** está alto (materiales “transparentes”), el IOR define el realismo físico de la refracción y el brillo.
    

**Resumen:**  
El IOR en Principled BSDF te ayuda a simular correctamente la manera en la que la luz interactúa con diferentes superficies, permitiéndote lograr materiales realistas para diseño, arte y visualización multidisciplinaria.