---
status: Por leer
tags:
  - Libro
  - Política
Autor: " Michael Burleigh"
Image: https://m.media-amazon.com/images/I/61CiFpzs0KL._SY522_.jpg
master folder: "[[Por leer]]"
---
