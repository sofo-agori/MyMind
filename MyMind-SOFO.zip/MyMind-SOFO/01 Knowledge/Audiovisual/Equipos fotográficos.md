Tengo una [[Lumix G85]], me parece la mejor camara, junto a la ZVE-10 para comenzar. Mi sueño es tener un gh6 o una s5ii. Me gustan las cámaras Panasonic porque son las mejores calidad/precio.

# Lista de Deseos

## Iluminación 
<div class="rich-link-card-container"><a class="rich-link-card" href="https://a.co/d/i6TbChM" target="_blank">
	<div class="rich-link-image-container">
		<div class="rich-link-image" style="background-image: url('https://m.media-amazon.com/images/I/61VUSj4IVsL._UF894,1000_QL80_FMwebp_.jpg')">
	</div>
	</div>
	<div class="rich-link-card-text">
		<h1 class="rich-link-card-title">Amazon.com : Amaran 100d LED Video Light, 100W CRI95+ TLCI96+ 39,500 lux@1m Bluetooth App Control 8 Pre-Programmed Lighting Effects DC/AC Power Supply, Made by Aputure : Electronics</h1>
		<p class="rich-link-card-description">
		
		</p>
		<p class="rich-link-href">
		https://a.co/d/i6TbChM
		</p>
	</div>
</a></div>

<div class="rich-link-card-container"><a class="rich-link-card" href="https://www.amazon.com/dp/B07L755X9G?ref=cm_sw_r_apan_dp_A3EEJYD11Z112B13MS6R_1&ref_=cm_sw_r_apan_dp_A3EEJYD11Z112B13MS6R_1&social_share=cm_sw_r_apan_dp_A3EEJYD11Z112B13MS6R_1&csmig=1" target="_blank">
	<div class="rich-link-image-container">
		<div class="rich-link-image" style="background-image: url('https://m.media-amazon.com/images/I/617mzv+iKjL._SL1500_.jpg')">
	</div>
	</div>
	<div class="rich-link-card-text">
		<h1 class="rich-link-card-title">Amazon.com: Elgato Key Light - Professional 2800 lumens Studio Light with desk clamp for Streaming, Recording and Video Conferencing, Temperature and Brightness app-adjustable on Mac, PC, iOS, Android : Electronics</h1>
		<p class="rich-link-card-description">
		Buy Elgato Key Light - Professional 2800 lumens Studio Light with desk clamp for Streaming, Recording and Video Conferencing, Temperature and Brightness app-adjustable on Mac, PC, iOS, Android: Camera & Photo - Amazon.com ✓ FREE DELIVERY possible on eligible purchases
		</p>
		<p class="rich-link-href">
		https://www.amazon.com/dp/B07L755X9G?ref=cm_sw_r_apan_dp_A3EEJYD11Z112B13MS6R_1&ref_=cm_sw_r_apan_dp_A3EEJYD11Z112B13MS6R_1&social_share=cm_sw_r_apan_dp_A3EEJYD11Z112B13MS6R_1&csmig=1
		</p>
	</div>
</a></div>
<div class="rich-link-card-container"><a class="rich-link-card" href="https://medphoto.cl/tienda/nanlite/nanlite-pavotube-ii-6c/?srsltid=AfmBOortWVIBeWF66BObPDqPM3Rjm16AlEswZFptR7IvH3PLRsF5dRnn" target="_blank">
	<div class="rich-link-image-container">
		<div class="rich-link-image" style="background-image: url('https://medphoto.cl/wp-content/uploads/2024/03/PAVOTUBE-II-6C-MEDPHOTO6.jpg')">
	</div>
	</div>
	<div class="rich-link-card-text">
		<h1 class="rich-link-card-title">Nanlite Pavotube II 6C</h1>
		<p class="rich-link-card-description">
		Los Nanlite Pavotube II 6C son un dispositivo de iluminación versátil increíblemente portátil, con un espectro completo RGB y efectos de iluminación.
		</p>
		<p class="rich-link-href">
		https://medphoto.cl/tienda/nanlite/nanlite-pavotube-ii-6c/?srsltid=AfmBOortWVIBeWF66BObPDqPM3Rjm16AlEswZFptR7IvH3PLRsF5dRnn
		</p>
	</div>
</a></div>

<div class="rich-link-card-container"><a class="rich-link-card" href="https://amarancreators.com/pages/amaran-ace-25c" target="_blank">
	<div class="rich-link-image-container">
		<div class="rich-link-image" style="background-image: url('https://amarancreators.com/cdn/shop/files/AceLock-ValueProp-Blank-1x1_18.png?v=1728686551&width=600')">
	</div>
	</div>
	<div class="rich-link-card-text">
		<h1 class="rich-link-card-title">amaran Ace 25c - Full-Color Compact LED Light for On-the-Go | Learn More</h1>
		<p class="rich-link-card-description">
		Designed for on-the-go creators, the amaran Ace 25c is a full color compact LED light that can recreate any color to make your content shine with the perfect shade. Featuring up to 32W of power output and the amaran Ace Lock, this brilliantly bright yet compact light is perfect for travel vloggers or influencers creating on-camera or creators shooting live events.
		</p>
		<p class="rich-link-href">
		https://amarancreators.com/pages/amaran-ace-25c
		</p>
	</div>
</a></div>


## Lentes

- [Panasonic LUMIX G Lens, 25mm, F1.7 ASPH](https://www.amazon.com/PANASONIC-LUMIX-MIRRORLESS-THIRDS-H-H025K/dp/B014RD6RC0)
- [Yongnuo YN42.5MM F1.7M II](https://a.co/d/549Baro)
- [Panasonic LUMIX G LENS, 42.5MM, F1.7 ASPH.](https://a.co/d/jm8ENPU)
## Otros

<div class="rich-link-card-container"><a class="rich-link-card" href="https://a.co/d/aMzUp11" target="_blank">
	<div class="rich-link-image-container">
		<div class="rich-link-image" style="background-image: url('https://m.media-amazon.com/images/I/81qecfT4XQL._UF1000,1000_QL80_.jpg')">
	</div>
	</div>
	<div class="rich-link-card-text">
		<h1 class="rich-link-card-title">Amazon.com : K&F Concept 58mm UV/CPL/ND Lens Filter Kit (3 Pieces)-18 Multi-Layer Coatings, UV Filter + Polarizer Filter + Neutral Density Filter (ND4) + Cleaning Cloth+ Filter Pouch for Camera Lens (K-Series) : Electronics</h1>
		<p class="rich-link-card-description">
		
		</p>
		<p class="rich-link-href">
		https://a.co/d/aMzUp11
		</p>
	</div>
</a></div>

<div class="rich-link-card-container"><a class="rich-link-card" href="https://a.co/d/1FgJiqw" target="_blank">
	<div class="rich-link-image-container">
		<div class="rich-link-image" style="background-image: url('https://m.media-amazon.com/images/I/71Tyy0AoOnL._UF1000,1000_QL80_FMwebp_.jpg')">
	</div>
	</div>
	<div class="rich-link-card-text">
		<h1 class="rich-link-card-title">Amazon.com : Neewer 5-in-1 Collapsible Multi-Disc Light Reflector 43 inches/110 centimeters and 6-Pack Muslin Backdrop Spring Clamps, Translucent/Silver/Gold/White/Black Reflector for Studio or Outdoor Photography : Electronics</h1>
		<p class="rich-link-card-description">
		
		</p>
		<p class="rich-link-href">
		https://a.co/d/1FgJiqw
		</p>
	</div>
</a></div>

