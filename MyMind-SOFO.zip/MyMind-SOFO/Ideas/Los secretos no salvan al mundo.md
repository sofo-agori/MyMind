Publicado en [Medium.com]()

Los secretos no salvan al mundo: mi problema con la [[masonería]]

## No es sobre conspiraciones 

Esta crítica no es fruto de teorías conspirativas ni de desconfianzas sobre la masonería -y otras logias hermanas- Lo que me inquieta de los masones no es lo que ocultan tras sus símbolos y sus raros rituales, sino la manera en que convierten el saber en un super-privilegio, un privilegio del que al parecer solo ellos son dignos. Mi desacuerdo es de fondo: todo saber verdadero debe ser compartido, no filtrado.

Convertir el secreto en rito y cultura es una ofensa a la inteligencia. Nada que valga la pena descubrir merece ser guardado bajo juramentos extraños o escalones iniciáticos.
## El conocimiento: columna principal del ser humano
Para mí, el conocimiento es el máximo bien terrenal; un fin al que muchos aspiramos, ajena a dueños o guardianes. El ideal filosófico, desde los estoicos hasta los nihilistas siempre fue el crecimiento a través del saber. La libertad es inseparable del acceso sin trabas a las ideas y la información.

Todo intento de privatizar el aprendizaje—sea por grados o jerarquías—es un retroceso de nuestra civilización. El elitismo intelectual mata el asombro. Aprender y enseñar libremente es un derecho, no una concesión.

La verdadera objeción a la masonería no es su mística, sino su modelo: una estructura escalonada que convierte el progreso intelectual en prueba secreta y pertenencia. ¿Por qué cerrar las puertas del conocimiento?

A lo largo de la historia, muchos grupos han protegido entendimientos avanzados bajo mil claves. Pero el progreso nunca vino de la exclusividad, sino del deseo de compartir. Cuanto más se encierren los conocimientos tras jerarquías y silencios, más lejos queda la posibilidad de un mundo que progrese.

## Contra el culto a la jerarquía
La masonería institucionaliza el saber como trayectoria jerárquica: "aprendiz, compañero, gran maestro". Pero el verdadero intelectual nunca termina de aprender. El modelo de grados refuerza una vieja patología cultural—el fetiche de la autoridad— Como si hay personas más dignas o menos dignas de adquirir cierto conocimiento.

El eterno aprendiz es quien encarna el ideal más noble: el de quien no quiere títulos, solo luz (no la iluminación que venden logias sincréticas. El conocimiento debe ser una experiencia horizontal, no vertical.

## El saber es un bien común, no moneda de intercambio
La historia cambió cada vez que el conocimiento se hizo grande: Jesús ofreciendo la verdad sin iniciaciones herméticos, Sócrates debatiendo en una plaza, y actualmente, las aplicaciones de código abierto. Las sociedades crecen cuando el saber se libera del control de elites y se multiplica entre todos nosotros. 

Toda institución que clasifica el pensamiento como mercancía es un obstáculo. El desafío es soltar viejos dogmas y abrazar la transparencia radical.

# Conclusión: menos misterio, más luz

No temo al poder de los símbolos ni a sus absurdos rituales iniciáticos; lo que temo es el empobrecimiento derivado de volver la curiosidad un privilegio. Los misterios forzados oscurecen el horizonte; y nubla la razón de una sociedad que tiene derecho al conocimiento.

El futuro pertenece a quienes comparten, no a quienes acaparan. En la época de la información, el verdadero rebelde publica, dialoga y difunde. El conocimiento es nuestro único escudo como sociedad para evitar ser aplastados por aquellos que hacen del saber un monopolio.

Por eso comparto, por eso escribo. 