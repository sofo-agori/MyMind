---
created: 2025-08-24
tags:
  - Software
  - Tecnología
Image:
Url:
---
Siempre me ha gustado probar softwares y apps. Es una de las cosas que mas disfruto y más si en el camino tengo que [[Piratería|Piratearlo]]. 

## Notes:
- [Deja de perfeccionar. Empieza a enviar. A tus usuarios les importa un bledo tu código limpio si tu producto es pésimo. He visto a ingenieros brillantes pasar meses construyendo la base "perfecta" para algo que nadie quería. Envía la versión fea. Obtén retroalimentación real. Itera rápido. Las cosas aburridas que resuelven problemas reales generan dinero. Las cosas "revolucionarias" no suelen generarlo.](https://www.reddit.com/r/software/comments/1myqcpe/10_years_building_products_taught_me_this/)

## Links
 - [Guides | Tech Lockdown](https://www.techlockdown.com/guides) - como bloquear apps 