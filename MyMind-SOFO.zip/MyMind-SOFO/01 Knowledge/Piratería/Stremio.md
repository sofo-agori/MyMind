## Links:
- [Comet - Addon](https://comet.elfhosted.com/configure) - Addon para conectar con Real-debrid
- [Ultimate guide to Stremio + Torrentio + RD - Reddit](https://www.reddit.com/r/StremioAddons/comments/yi5jdw/ultimate_guide_to_stremio_torrentio_rd/)