---
created: 2025-08-21
tags:
  - MotionGraphics
  - diseño
  - 3D
Image:
Url:
---
El motion graphics (diseño en movimiento) es una rama del [[Diseño]]. Quizás la que más me gusta. 
## Links:
- [(32) 12 Principles of Animation (Official Full Series) - YouTube](https://www.youtube.com/watch?app=desktop&v=uDqjIdI4bF4)

## Canales de Youtube:

```cardlink
url: https://www.youtube.com/@holke79/videos
title: "Holke79® Motion Design — Kinetic Typography"
description: "Holke79 creates Motion Design — Kinetic Typography. Kinetic Type Series is a series of videos with the aim of sharing my knowledge about something that I'm really passionate about: Kinetic Typography. Please consider subscribing if you are interested in the content! It will be updated and is 100% free.www.holke79.com"
host: www.youtube.com
favicon: https://www.youtube.com/s/desktop/5565b4e1/img/logos/favicon_32x32.png
image: https://yt3.googleusercontent.com/zemFRq_e-_amruB8zQECOgUTg4C7KFN7jCRq8t1ES-izLrcUM9eYDoDiyHz9l3wIF14Oi25ilg=s900-c-k-c0x00ffffff-no-rj
```
