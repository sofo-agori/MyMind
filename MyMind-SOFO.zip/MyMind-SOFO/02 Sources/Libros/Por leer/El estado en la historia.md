---
status: Leyendo
tags:
  - Libro
  - Anarquía
Autor: Gaston Leval
Image: https://m.media-amazon.com/images/I/51Add1hBi8L._UF1000,1000_QL80_.jpg
---
