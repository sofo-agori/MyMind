---
created: 2025-08-13
tags: []
aliases: []
---
### Links:
- [Diseño web brutalista](https://brutalist-web.design/) Pautas para el diseño web brutalista, Contenido crudo fiel a su construcción .
- [Invisible Details of Interaction Design](https://rauno.me/craft/interaction-design) Para mi uno de los mejores artículos sobre diseño en general 
