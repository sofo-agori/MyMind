- Mi mouse: [Logitech G502 X Lightspeed](https://a.co/d/gp5uod8)- Es una de mis mejores compras. Es sin duda el mejor mouse del mercado.
- Mi teclado: [Logitech Pebble Keys 2 K380s](https://a.co/d/6hf5OyF)-Me lo regaló mi novia. Es simple, sencillo y portable. Suena agradable. 
- Mis audífonos: [Audífonos Cubbit](https://cubitt.com.co/products/cubitt-headphones?srsltid=AfmBOoqNJ_1o52sqQRGZLalCzAT-7f0xztCeLfV72NaAAOe_ClRqIl-d) - Me lo regaló mi novia. Buen sonido, buena cancelación de ruido. 

## Deseos:

```cardlink
url: https://www.skullcandy.com/products/rail-anc-true-wireless-earbuds
title: "Rail ANC - True Wireless Earbuds with Active Noise Canceling | Bluetooth 5.2 | Built-in Microphone | Tile Tracking"
description: "Skullcandy's Rail® ANC true wireless earbuds combine all of our top tech with active noise canceling for the ultimate on-the-go audio experience."
host: www.skullcandy.com
favicon: https://www.skullcandy.com/cdn/shop/files/skull_logo_white_background_Favicon.png?crop=center&height=32&v=1717532670&width=32
image: http://www.skullcandy.com/cdn/shop/files/RailANCTrueBlackBuyBox1.png?v=1709610333
```


```cardlink
url: https://electronics.sony.com/audio/headphones/headband/p/wh1000xm4-b?mg=search&&&&&gclsrc=aw.ds&gad_source=1&gad_campaignid=20410195384&gbraid=0AAAAABiDjZiUMLV4Iav0kHvIhHIKQYpZe&gclid=Cj0KCQjwzaXFBhDlARIsAFPv-u9RoL_ylnuj8TJ8nFfu0hQmQHZhKqUJp5lk0lUz21pjuXgCghUzm-AaAjyMEALw_wcB
title: "Sony WH-1000XM4 Premium Wireless Noise Canceling Headphones | Black"
description: "Sony WH-1000XM4 Wireless Noise Canceling Over-the-Ear Headphone in black. Wireless Bluetooth streaming and Smartphone compatibility for hands-free."
host: electronics.sony.com
image: https://d1ncau8tqf99kp.cloudfront.net/converted/74739_original_local_1200x1050_v3_converted.webp
```


```cardlink
url: https://a.co/d/67HGpDE
title: "Amazon.com: SSK Portable SSD 1TB External Solid State Drives, up to 1050MB/s USB C SSD External Hard Drive USB 3.2 Gen2 for iPhone 15/Pro, Windows, Mac, Android Phones and Tablets : Electronics"
description: "Amazon.com: SSK Portable SSD 1TB External Solid State Drives, up to 1050MB/s USB C SSD External Hard Drive USB 3.2 Gen2 for iPhone 15/Pro, Windows, Mac, Android Phones and Tablets : Electronics"
host: a.co
image: https://c1.neweggimages.com/productimage/nb640/AZS4S23010503NXEJ88.jpg
```


```cardlink
url: https://a.co/d/ahZyemU
title: "Amazon.com: HIFI WALKER H2 HiFi MP3 Player with Bluetooth 5.2, Lossless DSD FLAC Player, Digital Audio Player Hi Res Portable Music DAP Player with 64GB Micro SD Card, Support Up to 512GB : Electronics"
description: "Amazon.com: HIFI WALKER H2 HiFi MP3 Player with Bluetooth 5.2, Lossless DSD FLAC Player, Digital Audio Player Hi Res Portable Music DAP Player with 64GB Micro SD Card, Support Up to 512GB : Electronics"
host: a.co
image: https://m.media-amazon.com/images/I/71sQuUCxK9L._UF894,1000_QL80_FMwebp_.jpg
```

## Links:
- [What Is a KVM Switch and Why Use It? - Anker US](https://www.anker.com/blogs/hubs-and-docks/what-is-a-kvm-switch) - Un conmutador sirve para cambiar de gadgets rápidamente entre distintas computadoras.
- [ACASIS 40Gbps M.2 NVMe SSD](https://a.co/d/j1nBSik) - Carcasa para disco duro
- [WORK LOUDER®](https://worklouder.cc/knob1) - teclado precioso. [^1]

[^1]: https://x.com/adamwathan/status/1961402437908005337
