---
status: Por leer
tags:
  - Libro
  - Religión
Autor: Anónimo
Image: https://images.cdn1.buscalibre.com/fit-in/360x360/11/fd/11fdbff91cb210db4f1518b6d8315b3e.jpg
master folder: "[[Por leer]]"
---
