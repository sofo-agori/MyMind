---
created: 2025-08-20
tags:
  - Plugins-After
Image: https://cdn.motiondesign.school/uploads/2021/05/super-morphings_Promo_%D0%A1over-1.png
Url:
master folder: "[[Plugins de After Effects]]"
---

Es un plugin de After Effects que Convierte formas en otras. 

![Super Morphings - Motion Design School](https://cdn.motiondesign.school/uploads/2021/05/super-morphings_Promo_%D0%A1over-1.png)

