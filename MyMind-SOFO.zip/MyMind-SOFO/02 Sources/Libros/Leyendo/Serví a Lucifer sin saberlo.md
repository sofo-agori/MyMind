---
created: 2025-08-22
tags:
  - Libro
  - Masonería
Image: "[[Serví a Lucifer sin saberlo.png]]"
status: Leyendo
Autor: Serge Abad-Gallardo
master folder: "[[Leyendo]]"
---

La masonería tiene lazos, disimulados, pero estrechos con la doctrina luciferina. Entiéndase por luciferina la perversión del bien, de la libertad, haciendo que todo esto de incline hacia el mal.

	Y es que, como decía Georges Bernanos, «por muy sutil que sea el enemigo, su malicia más ingeniosa solo podría alcanzar el alma mediante un rodeo, así como se toma una ciudad envenenando sus fuentes. Engaña el juicio, ensucia la imaginación, conmueve la carne y la sangre, aprovecha con arte infinito nuestras propias contradicciones (…), falsea los actos y las intenciones4».
