---
created: 2025-08-27
tags:
  - Internet
  - Tecnología
  - Software
Image:
Url:
master folder: "[[Software]]"
---
El [[Software]] open source es un código diseñado de manera que sea accesible al público: todos pueden ver, modificar y distribuir el código de la forma que consideren conveniente.

## Links:
- [¿Qué es el open source o código abierto?](https://www.redhat.com/es/topics/open-source/what-is-open-source)
- [Best open-source software that everyone needs to know about? : r/software](https://www.reddit.com/r/software/comments/1n0jh36/best_opensource_software_that_everyone_needs_to/)

## Softwares open sources:
- [[Blender]] - Software 3D. Para mi el mejor programa que se ha hecho.
- [HandBrake: Open Source Video Transcoder](https://handbrake.fr/) - Similar a Media Encoder. 
- [VLC, ](https://images.videolan.org/vlc/index.es.html) - Reproductor de Video
- [Shutter Encoder](https://www.shutterencoder.com/) - Convertidor
- [AutoHotkey](https://www.autohotkey.com/) - automatización en windows basada en scripts
- [KDE Connect](https://kdeconnect.kde.org/) - Comparte archivos entre tu teléfono y tu computados (Deben estar la misma red)
-  [Everything](https://www.voidtools.com/)-Busca todo en tu computadora
- [Microsoft PowerToys](https://learn.microsoft.com/en-us/windows/powertoys/) - Windows ToolKit
- [AIMP](https://www.aimp.ru/?do=download&os=windows) - Reproductos de Música
- [darktable](https://www.darktable.org/) - Como Lightroom
- [Inkscape Inkscape https://inkscape.org](https://inkscape.org/) - Como Illustrator. Gráficos vectoriales.
- [Scribus](https://sourceforge.net/projects/scribus/) - Maquetación de paginas. Como Indesign.
- [GIMP - GNU Image Manipulation Program GIMP https://www.gimp.org](https://www.gimp.org/) - Programas de manipulación de imagenes. Similar a Photoshop.
- ==[mifi/lossless-cut: La navaja suiza de la edición de vídeo y audio sin pérdidas](https://github.com/mifi/lossless-cut) - Cortar videos rápidamente.==
- [FreeMind](https://sourceforge.net/projects/freemind/) - Mapas Mentales.
- [Bulk Crap](https://www.bcuninstaller.com/) - Desinstalar programas.
- [Audacity ® | Free Audio editor, recorder, music making and more!](https://www.audacityteam.org/) - Editor de audio. 