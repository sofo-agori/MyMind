Tengo una asus tuf gaming f15 fx507ze:
- Intel i7 12700h
- Rtx 3050 ti
- 24 Gb de ram 4800mhz
- 512 m2 ssd

cosas que quiero agregar
- [ ] [SSD - 1TB - SAMSUNG](https://a.co/d/fLzqsw4)
- [ ] [ DDR5 RAM 32GB (1x32GB) 4800MHz](https://a.co/d/95SAYGy)


Ya estoy planteandome cambiar a una nueva laptop. Me gustaría mantenerme en el ecosistema Windows. Aún no decido cual será mi próxima laptop.

### Modelos que me gustan
- [ROG Zephyrus Gaming Laptop - All Models｜Laptops For Gaming｜ASUS USA](https://www.asus.com/us/laptops/for-gaming/all-series/filter?SubSeries=ROG-Zephyrus) - De seguir con una linea continuista. He tenido buena experiencia junto a asus.
- [ASUS Vivobook S 15 15.6" 3K OLED Laptop Copilot+ PC Snapdragon X Elite 32GB Memory 1TB SSD Cool Silver S5507QAD-PS99 - Best Buy](https://www.bestbuy.com/product/asus-vivobook-s-15-15-6-3k-oled-laptop-copilot-pc-snapdragon-x-elite-32gb-memory-1tb-ssd-cool-silver/JJGGLQ3PF9/sku/6626050?utm_source=Perplexity&utm_medium=referral&utm_source=perplexity) - Esta es Snapdragon. Es una propuesta interesante.
- [Amazon.com: Dell G15 5530 Gaming Laptop, NVIDIA RTX 4060, Intel i9-13900HX(Up to 5.4GHz, 36 MB Cache), 15.6" 1920x1080 165Hz 3ms Display, 64 GB DDR5, 1 TB SSD, Backlit Keyboard, Windows 11 Pro : Electronics](https://a.co/d/14Se0aI) Este modelo me encanta visualmente 
 - [Amazon.com: Apple 2025 MacBook Air 13-inch Laptop with M4 chip: Built for Apple Intelligence, 13.6-inch Liquid Retina Display, 16GB Unified Memory, 512GB SSD Storage, 12MP Center Stage Camera, Touch ID; Midnight : Electronics](https://a.co/d/j7eAY6e) Si llego a cambiar a ios esta va a ser la elegida.
 
---

- Esta laptop me gusta bastante: [HONOR MagicBook Art 14 - Battery, Processor - HONOR Global](https://www.honor.com/global/laptops/honor-magicbook-art-14/)
- 