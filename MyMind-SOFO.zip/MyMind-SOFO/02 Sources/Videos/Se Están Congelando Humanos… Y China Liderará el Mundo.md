
Extracto del Podcast de Aladetres con Felipe Debasa (Técnologo) [(34) Se Están Congelando Humanos… ¿Y China Liderará el Mundo? - Felipe Debasa | Aladetres 137 - YouTube](https://www.youtube.com/watch?v=jJ0ZlS-PZNw)

18:23 - Como se bajan los reels se asemeja mucho como eran las maquinas tragas perras antiguamente. Esa adicción es la que nos hace que NO podamos disfrutar nada tranquilamente.

19:42 - Te preocupa que la gente no le libros? NO, a mi lo que me preocupa es que la gente no conozca la tecnología. Porque la tecnología no es mala ni buena. 

22:28 Que nos escuchen los teléfonos en manipulación. Imagínate que nos tomen una foto, y si en la foto se ve si estamos deprimidos o felices, el algoritmo sea capaz de verlo. 

29:57 Cuando se habla de una catástrofe no se puede hablar solo de guerra, pueden ser ataques cibernéticos, ataques hacia la energía eléctrica, hacia semáforos, telecomunicaciones. 

31:57 Cuantas mas información hay, mas aparecen las pseudociencias. 

> [!NOTE]
> De esto se habla en el libro [[El Mundo y sus demonios]]
> 