---
tags:
  - Fotografía
  - Camara
  - Video
---
![[Velocidad de obturacion.jpg]]

- Para evitar trepidación a pulso: usa al menos 1/(focal equivalente) como regla rápida; por ejemplo, 1/50s con 50mm, 1/200s con 200mm.

- Para congelar acción rápida: empieza en 1/1000s (deportes, aves en vuelo) y ajusta según el movimiento; si falta luz, [[Apertura|abre diafragma]] o sube ISO.

- Para crear movimiento intencional: usa velocidades lentas (1/30s a varios segundos) con trípode; prueba barridos entre 1/15s y 1/60s para sujetos en movimiento.
