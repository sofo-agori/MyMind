---
status: Por leer
tags:
  - Libro
  - Venezuela
Autor: Augusto Mijares
Image: https://misionverdad.com/sites/default/files/Captura%20desde%202023-07-04%2015-17-15.png
master folder: "[[Por leer]]"
---
https://museosbolivarianos.mincyt.gob.ve/libros/PDF%2000065-Lo%20Afirmativo%20Venezolano%20Augusto%20Mijares.pdf