Activas:
- Drive: 2.99$
- RealDebrid: 4$ / meses 
- Adobe: 10$ / 3 meses (27 de noviembre)
- Capcut 10$ / meses
- Groupaly 3$ / mes