---
created: 2025-08-17
tags:
  - Libro
  - Ciencia
  - Conocimiento
aliases: []
Autor: Carl Sagan
status: Leyendo
Image: "[[El Mundo y sus demonios.png]]"
master folder: "[[Leyendo]]"
---
