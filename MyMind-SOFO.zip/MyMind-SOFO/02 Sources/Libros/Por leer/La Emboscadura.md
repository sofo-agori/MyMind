---
status: Por leer
tags:
  - Libro
Autor: Ernst Junger
Image: https://m.media-amazon.com/images/I/71DXlfITUJL._UF350,350_QL50_.jpg
master folder: "[[Por leer]]"
---
