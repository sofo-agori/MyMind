- Quien crees que puso de moda el quejido con autotune
- Entre frases y refranes y frases que alarga en el tempo, trapani tiene un estilo reconocibles 

- Se que estas cansado de oir "el idolo de tu idolo" para simplemente decir un artista under que en realidad no es under.
