---
created: 2025-08-14
tags:
  - bienestar
  - salud
  - articulo
aliases:
Url: https://www.meghantelpner.com/healthwashing/
---
Tendemos a elegir productos que no son saludables porque nos dejamos llevar lo que dice el empaque. 

---

Términos conocidos
- Bajo en grasa
- Bajo en calorías
- Sin grasa
- Sin azúcar
- Natural
- 100% natural
- Fortificado con (Vitamina D, Vitamina C, calcio, etc.)
- Elaborado con ingredientes totalmente naturales.
- Hecho con ingredientes reales
- Hecho con fruta real
- Bajo en sodio
- Colesterol bajo
- Sin colesterol
- Fuente de fibra
- Fuente de omega-3
- Fuente de probióticos
- Proporciona el X% de la cantidad diaria recomendada de (proteínas, fibra, calcio, hierro, etc.)
- Libre de…(colorantes artificiales, sabores artificiales, etc.)
- Sin gluten
- Sin lácteos
- Vegano
---

Cosas como natural no están para nada reguladas, y etiquetas como bajo en sodio o en grasa es muy ambiguo, porque solo puede necesitar un dosis mínima por abajo de lo estipulado para entrar en esta categoría. 

Con estas etiquetas solo buscan perfumar la basura. 

# Maneras de detectar el healthwashing

1. Lee primero la etiqueta completa

2. Natural y orgánico no tiene que ser igual a saludable

3. Con colorante natural no quiere decir que sea 100% natural. Esos colorante llevan un proceso quimico extensivo

4. Una etiqueta grande puede significar que el producto sea igual o mas dañino

5. Una buena formar de hacerle frente a esto es evitar cualquier producto que tenga una etiqueta que intenta alabarse asimisma. 

6. Las afirmaciones gubernamentales son peores

7. Cuidado con la división de ingredientes, como por ejemplo: el azúcar en glucosa, fructosa, azúcar de caña, azúcar de remolacha, jarabe de maíz, malta de cebada, melaza, etc.
