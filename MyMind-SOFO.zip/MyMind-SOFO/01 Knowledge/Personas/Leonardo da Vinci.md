---
created: 2025-08-06
tags:
  - DaVinci
  - Personas
  - Historia
Image: https://hips.hearstapps.com/hmg-prod/images/portrait-of-leonardo-da-vinci-1452-1519-getty.jpg?crop=1xw:1.0xh;center,top&resize=640:*
Descripción: Polímata
---
## Observaciones y pensamientos

- Leonardo Da Vinci es uno de los personajes históricos que más me inspiran por su asombrosa capacidad para integrar arte, ciencia y tecnología. Su curiosidad ilimitada y su búsqueda incansable de conocimiento son modelos para cualquier creativo o profesional multidisciplinar.
    
- Me motiva profundamente su ejemplo de no conformarse con un solo campo del saber: desde anatomía hasta arquitectura, desde pintura hasta invención de máquinas, Leonardo rompía barreras mentales y culturales.
    
- Me intriga la imagen popular del “hombre renacentista” y cómo muchos de sus apuntes y dibujos permanecieron ocultos siglos, cobrando nueva relevancia en la era contemporánea.
    
- Veo en su obra una invitación a explorar pensamientos visuales, crear conexiones inesperadas y buscar siempre la belleza y la precisión.
    

## Preguntas abiertas

- ¿Cómo aplicaba Leonardo sus descubrimientos científicos a su arte y viceversa?
    
- ¿Cuáles de sus inventos realmente funcionaron o se adelantaron a su tiempo de manera práctica?
    
- ¿Cómo influyó su formación en el taller de Verrocchio en su modo de pensar y crear?
    
- ¿Qué impacto directo tienen hoy sus estudios de anatomía y diseño en la ciencia y el arte actuales?
    
- ¿Por qué guardaba ciertos descubrimientos en secreto y no los compartía de inmediato?
    

## Enlaces internos

- [[Renaissance Humanismo]]
    
- [[Diseño y naturaleza]]
    
- [[Cuadernos de bocetos e ideas]]
    
- [[Innovadores multidisciplinarios]]
    
- [[Historia de la ingeniería]]
    
- [[Artistas y ciencias mezcladas]]
    

## Enlaces externos

- [Leonardo da Vinci | Biography, Art, Paintings, Mona Lisa – Britannica](https://www.britannica.com/biography/Leonardo-da-Vinci)
    
- [Leonardo da Vinci – Wikipedia](https://en.wikipedia.org/wiki/Leonardo_da_Vinci)
    
- [Science and inventions of Leonardo da Vinci – Wikipedia](https://en.wikipedia.org/wiki/Science_and_inventions_of_Leonardo_da_Vinci)
    
- [Leonardo da Vinci Paintings, Bio, Ideas – The Art Story](https://www.theartstory.org/artist/da-vinci-leonardo/)
    

## Notas

- “Learning never exhausts the mind.” – Leonardo da Vinci
    
- “El arte nunca termina, solo se abandona.” – Atribuido a Leonardo
    
- “Mientras pensaba que estaba aprendiendo a vivir, he estado aprendiendo a morir.” – Leonardo da Vinci
    

## Conexiones y analogías

- Veo analogías entre los cuadernos de Leonardo y los sistemas modernos de Second Brain: ambos buscan, desde la anotación y la observación, conectar ideas y fomentar la creatividad.
    
- Su “Hombre de Vitruvio” es puente entre arte y matemáticas, recordando cómo el diseño, la proporción y la observación se reflejan en la naturaleza y la ciencia.
    
- Así como en Blender se modelan objetos en 3D, Leonardo descomponía cuerpos humanos en estudios anatómicos para entender su estructura y funcionamiento.
    
- Su enfoque interdisciplinario inspira la cultura maker y los laboratorios de fabricación digital de hoy.
    
- Leonardo como precursor del biomimetismo: observaba la naturaleza para inventar soluciones (alas, vehículos, maquinaria).
    

## Tareas y experimentos

-  Dibujar un “cuaderno de Leonardo” propio: bocetos, ideas y apuntes diarios de cosas que observe, integrando texto e imágenes.
    
-  Reproducir digitalmente el “Hombre de Vitruvio” usando Illustrator, explorando las proporciones y matemáticas detrás del dibujo.
    
-  Investigar a fondo una de sus máquinas voladoras y modelarla en 3D utilizando Blender.
    
-  Realizar una infografía sobre las conexiones entre arte y ciencia inspiradas por Leonardo.
    
-  Crear una animación sencilla que explique su método del “sfumato” en Procreate o After Effects.
    
- Si realizo la animación, reflexionaré sobre cómo la técnica afecta la percepción visual moderna.
    

## Proyectos

- **Render 3D: “Máquinas aéreas de Leonardo”**  
    Herramienta: Blender  
    Reflexión: Me atrae imaginar cómo se verían sus inventos con tecnología y materiales actuales; espero mejorar habilidades de modelado y visualizar ideas históricas con mirada contemporánea.
    
- **Infografía: “El Hombre de Vitruvio y sus proporciones”**  
    Herramienta: Illustrator  
    Reflexión: Buscaré comunicar visualmente los vínculos entre arte, geometría y biología; me interesa hacer asequible este conocimiento a todo público.
    
- **Collage digital: “Universo Leonardo”**  
    Herramienta: Procreate  
    Reflexión: Exploraré la superposición de disciplinas, bocetos e ideas, inspirando a crear imágenes híbridas que mezclen ciencia, naturaleza y arte.
    

## Entrenamiento

- **Libro:** “Leonardo da Vinci” — Walter Isaacson. Biografía fundamental, explora el genio, las obsesiones y el método de trabajo de Leonardo Da Vinci.

- **Libro:** [[How to Think Like Leonardo da Vinci ]]— Michael J. Gelb 
-
- **Película / Documental:** “Inside the Mind of Leonardo” (2013). Documental que visualiza su proceso creativo a través de sus cuadernos y dibujos.
    
- **Conferencia / Curso / Podcast:** “How to Think Like Leonardo da Vinci” — Michael J. Gelb (TEDx Talk / Charlas). Motiva a aplicar sus principios para potenciar la creatividad y el pensamiento analítico.