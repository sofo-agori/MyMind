---
created: 2025-08-25
tags:
  - Personas
  - Youtuber
Image: https://upload.wikimedia.org/wikipedia/commons/thumb/5/54/Miles_Routledge_Catholic.jpg/250px-Miles_Routledge_Catholic.jpg
Url: https://en.m.wikipedia.org/wiki/Miles_Routledge
Descripción: Youtuber
---
Miles, youtuber britanico que fue a Afganistan en plena oleada ofensiva de los talibanes. Para luego ser evacuado por los ingleses. En 2023 volvió, esta vez cayendo preso. Le gusta hacer turismo atrevido. Me gusta su irreverencia. 

Su canal de youtube: https://www.youtube.com/@LordMiles/videos

