---
created: 2025-08-11
tags:
  - Personal
  - Sobre
  - Maniefiesto
aliases:
---
Para mi el tema de las drogas es un tema complejo. No soy consumidor, y creo que no llegaré a serlo. Y hasta puedo llegar a criticar al que destruye su vida con algún tipo de droga dura. Pero, hace poco entendí el significado de las drogas con respecto a la libertad. No se trata de lo que consumes, se trata de que si te dejan o no.

Las drogas y la [[Religión]] son dos cosas tan antiguas como la existencia del ser humano. Ambas son alborotadoras de la conciencia. Las drogas es un conector interior, las creencia un conector exterior. 

## Links:
- [DrugsData.org: Additional Resources and Links](https://www.drugsdata.org/additional_resources.php) Directorio de páginas que revisan y analizan drogas al rededor del mundo
