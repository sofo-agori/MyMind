---
created: 2025-08-14
tags:
  - TeVerde
  - Personal
  - Alimentación
aliases:
---
El te verde para mi es mas que una simple bebida, es gasolina para mí. Es lo que me ha salvado muchas veces. En los días más difíciles un té verde me ha resuelto mucho. 

## Puntuaciones de lugares:
- Gurman: 1/5
- Migas: 4/5
- Margarite: 2.5/5
- Páramo Café (milenium) : 4.5/5
- Canel: 2/5
- Bonsai Bar: 2.5/5
- Buddha Bar: 4.5/5
- Vero Caffe Bar: 3.5/5
- Socado (Limonada matcha): 5/5
- Páramo Café (Avila) (Te verde frappe) 0/5
- Gurman: 1/5
- Migas: 4/5
- Margarite: 2.5/5
- Páramo Café (milenium) : 4.5/5
- Canel: 2/5
- Bonsai Bar: 2.5/5
- Buddha Bar: 4.5/5
- Vero Caffe Bar: 3.5/5
- Socado (Limonada matcha): 5/5
- Páramo Café (Avila) (Te verde frappe) 0/5