---
tags:
  - diseño
---
## Notas
- [En gráficos vectoriales , las curvas de Bézier se utilizan para modelar curvas suaves que pueden escalarse indefinidamente. Las "trayectorias", como se las conoce comúnmente en los programas de manipulación de imágenes, Son combinaciones de curvas de Bézier enlazadas. Las rutas no están sujetas a los límites de las imágenes rasterizadas y son intuitivas de modificar. ](https://en.wikipedia.org/wiki/B%C3%A9zier_curve)
- En [[Motion Graphics]] Las curvas de Bézier también se utilizan en el dominio del tiempo, particularmente en animación, Diseño de interfaz de usuario y suavizado de la trayectoria del cursor en interfaces controladas por la mirada. Por ejemplo, una curva de Bézier puede utilizarse para especificar la velocidad temporal de un objeto, como un icono, que se mueve de A a B, en lugar de simplemente moverse a un número fijo de píxeles por paso. Cuando los animadores o diseñadores de interfaces hablan de la "física" o la "sensación" de una operación, pueden referirse a la curva de Bézier específica utilizada para controlar la velocidad temporal del movimiento en cuestión.
## Links:
- [0º or 90º: A Technique to Improve Your Vectors - Jake Rainis](https://jakerainis.com/blog/0-90-technique-improve-vectors/)
- [Una introducción a las curvas de Bézier](https://pomax.github.io/bezierinfo/)
- [The Bézier Game](https://bezier.method.ac/) - juego para mejorar
- [Freya Holmér en X: "A thread, on the ever so lovely Bézier curve ✨ https://t.co/2Mo5OjVIJ9" / X](https://x.com/FreyaHolmer/status/1063633408411295744)
- [curva de Bézier](https://javascript.info/bezier-curve)
- [(35) The BEST bezier curve tutorial for new Blender users. - YouTube](https://www.youtube.com/watch?v=f53GvpTIO2w) 