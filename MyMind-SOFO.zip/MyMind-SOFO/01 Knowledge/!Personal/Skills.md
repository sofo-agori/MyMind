---
created: 2025-08-11
tags: 
aliases:
---
Capacidades:
- [[Diseño]]
- [[Branding]]
- [[Edición de video]]
- Comunicación visual

Tecnico: 
- [[Illustrator]]: Fue el primer programa que aprendí, al rededor de 14 años cuando abrí el programa por primera vez
- [[Photoshop]]: Aprendí un poco a la par que con illustrator, no lo uso tanto en mi día a día pero lo tengo bajo control
- [[After Effects]]: Quizás mi programa favorito, tengo aprendido toda la parte que es para motion graphics, pero me falta adentrarme hacia la parte de VFX y 3D
- [[Blender]]: Sigo aprendiendolo, tengo una muy buena base. Es sin duda el mejor programa que existe. Por lo que tiene, por lo que lo rodea.
- Capcut
- Da Vinci
- Premiere
- Figma

Lo que me gustaría aprender:
- [[001 Ingles]]
- Webflow
- Cinema 4D
- Ableton
