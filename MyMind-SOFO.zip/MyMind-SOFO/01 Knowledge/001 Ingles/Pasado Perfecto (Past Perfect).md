---
created: 2025-08-12
tags: []
aliases: []
master folder: "[[001 Ingles]]"
---
El pasado perfecto se utiliza para hablar de una acción que ocurrió **antes de otra acción en el pasado**. Se forma con el verbo auxiliar **`had`** seguido del **participio pasado** del verbo principal.

Se usa para establecer una secuencia de eventos en el pasado.

- `When I arrived, the movie **had started**.` (Cuando llegué, la película **había empezado**.) – La película empezó primero (pasado perfecto) y luego yo llegué (pasado simple).
    
- `She said she **had seen** the play before.` (Ella dijo que **había visto** la obra de teatro antes.) – Primero vio la obra (pasado perfecto) y luego lo dijo (pasado simple).