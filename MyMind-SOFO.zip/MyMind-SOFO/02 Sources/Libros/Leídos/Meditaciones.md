---
created: 2025-08-22
tags:
  - Libro
  - filosofía
  - Estocismo
Autor: Marco Aurelio
status: "[[!Leídos]]"
Image: "[[Meditaciones.png]]"
master folder: "[[Leídos]]"
---
