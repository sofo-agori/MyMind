---
tags:
  - Fotografía
  - Camara
  - Video
---
![[Distancia Focal.png]]

- Mientras mayor es la distancia focal, mas desenfocado será el fondo.
- La equivalencia entre un lente m43 y uno fullframe se hace multiplicando x2.
- Los lentes zoom (distancia focal variable) las [[Apertura]] se va haciendo menor mientras mayor se hace la distancia focal.
## Links:
- [YouTube: NO COMPRES UNA OPTICA HASTA QUE VEAS ESTE VIDEO | DISTANCIAS FOCALES TODO LO QUE NECESITAS SABER](https://youtu.be/2wbrSRFfadI?si=7_vgiyspHHL0v-7i)
- [Lens comparison with all the @meike_global lenses I own, what's your go to focal length ?](https://www.instagram.com/reel/DMiUxxXOLN-/?igsh=MW5yeTRqMG13eDZrbQ==)
- 