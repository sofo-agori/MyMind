---
created: 2025-09-03
tags: []
Image:
Url:
master folder:
---
En principio, es un término creado por Giorgio Vasari en el siglo XVI. Que se creó con el fin de etiquetar el arte que venía del centro y norte de europa (Desde Alemania hacia arriba).

Según Vasari era arte poco armónico.

![[Arte Gótico.png]]

Según veo, no es falta de armonización. Lo que veo es más crudo, más real. No exalta la belleza como el arte renacentista. Remarca la religiosidad.

El arte gótico deja claro que no es "bello", pero no por eso no deja de ser impactante y majestuoso. Los pintores, como Stefan Lachner, no buscaban una expresión artística como si hacían sus similares renacentistas, el busca monumentos de culta, de ofrendas (a menudo en piezas llamados retablos).

Era más observación que estudio. En la mayoría de pinturas y esculturas la perspectiva y la anatomia no era tan buena (aunque a veces usada como discurso) pero la técnica en cosas como el oro, las piedras preciosas, y otros detalles eran casi perfecta.

Note

Los eruditos de la época pensaban que las moscas eran el pájaro más pequeño, y por otro lado, los artistas goticos las pintaban con exactitud y extrema delicadeza. Esto dice que el mundo se capta desde la observación y que en la exploración de la naturaleza el arte lleva la delantera.

![[Arte Gótico 01.png]]

Los rasgos de las personas en las pinturas son grotescos, feos, pero con infinidad de detalles. Mostrando así la vida común, acercado el arte al 'populacho' y mostrándose como son:

![[Arte Gótico 02.png]]

## Artistas góticos:
- Stefan Lachnerk
- Martin Schongauer
- Hans Multscher

--- 

## Links:
- [Erotismo, muerte y el demonio - Como el arte del gótico hechizaba a la gente | DW Documental - YouTube](https://www.youtube.com/watch?v=dayIvRiGx7s&feature=youtu.be)