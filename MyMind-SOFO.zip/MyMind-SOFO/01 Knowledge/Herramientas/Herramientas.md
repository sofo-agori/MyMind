---
created: 2025-08-13
tags:
  - "#Herramientas"
  - Tecnología
aliases: []
---



## Herramientas increíbles:
- [Download HTTrack Website Copier 3.49-2 - HTTrack Website Copier - Free Software Offline Browser (GNU GPL)](https://www.httrack.com/page/2/) - Guardar páginas web
-

---

## Links:
- [Uses This / Interviews](https://usesthis.com/) - Entrevistas para ver que herramientas - usan las personas
