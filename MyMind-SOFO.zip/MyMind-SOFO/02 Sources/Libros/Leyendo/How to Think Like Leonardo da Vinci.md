---
created: 2025-08-06
tags:
  - DaVinci
  - Conocimiento
  - Libro
aliases:
Autor: Michael Gelb
status: Leyendo
Image: "[[How to Think Like Leonardo da Vinci.png]]"
master folder: "[[Leyendo]]"
---
