---
created: 2025-08-22
tags:
  - Personal
Image:
Url:
---
Escribo sobre muchos temas, con especie de notas conceptuales (notas cortas y medianas con ideas y anotaciones sobre una extensa variedad de temas).

Me encanta la idea de que cada tema -nota- tenga **links** que sirvan como vía para profundizar en los temas, como una especie de bibliografía propia. Y también que tenga **notas**, que son frases, anotaciones e ideas de **otras personas**. Soy flexible con el formato de mis notas, así que esto solo es una guía y no reglas como tal.

---

Uso [[Obsidian]] para la toma de notas. En [[Raindrop]] guardo links sobre todo, de los que luego saco conocimiento. En[[ Eagle.cool]] va todo lo que es referencia y activo creativo. 

## Referencias:
- [Fork My Brain - Fork My Brain](https://notes.nicolevanderhoeven.com/Fork+My+Brain)
- [My Knowledge Wiki 🌿 | Everything I Know](https://wiki.nikiv.dev/)
- [Welcome to my digital garden - Alexis Rondeau - Obsidian Publish](https://publish.obsidian.md/alexisrondeau/Welcome+to+my+digital+garden)
- [barnsworthburning](https://barnsworthburning.net/#5a11c3c2-c8b6-4473-b7bf-162bd5066a7d)

## Links:
- [My Read it later and discoverability systems in 2025 | Daniel Prindii](https://danielprindii.com/blog/my-read-it-later-and-discoverability-systems)
- [Flujo de trabajo de artículos web: r/ObsidianMD](https://www.reddit.com/r/ObsidianMD/comments/mh12cl/web_article_workflow/)
