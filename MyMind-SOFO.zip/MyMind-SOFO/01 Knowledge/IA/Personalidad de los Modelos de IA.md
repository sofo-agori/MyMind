

| Modelo                     | Tipo de personalidad (más reconocible) | Analogía rápida (español neutro)                                              |
| -------------------------- | -------------------------------------- | ----------------------------------------------------------------------------- |
| Perplexity Sonar           | El Profe exigente pero justo           | Cita todo, ordena ideas con rigor y te entrega respuestas bien fundamentadas. |
| Claude Sonnet 4.0          | El Mentor zen del taller               | Te guía con preguntas calmadas y empáticas para abrir nuevas perspectivas.    |
| Claude Sonnet 4.0 Thinking | El Razonador metódico                  | Piensa con paciencia, explica cada paso y no deja cabos sueltos.              |
| Claude Opus 4.1 Thinking   | El Debateador quirúrgico               | Desarma argumentos, vuelve sobre ellos y afina la precisión del análisis.     |
| GPT-5                      | El Compañero todo‑terreno              | Responde rápido, conoce de muchos temas y se expresa con naturalidad.         |
| Gemini 2.5 Pro 06-05       | El Arquitecto de procesos              | Ordena el caos con diagramas y marcos claros para tomar decisiones.           |
| Grok 4                     | El Amigo techie acelerado              | Habla al ritmo de internet, mete humor y se va por tangentes interesantes.    |
| o3                         | El Maker curioso                       | Prueba, ajusta y aprende sobre la marcha; es flexible y creativo.             |
| o3‑pro                     | El Polímata práctico                   | Integra muchas fuentes y arma respuestas potentes con soltura.                |
| ChatGPT‑4o                 | El Creativo multimedia                 | Combina texto, imagen y audio para idear y prototipar sin fricción.           |
| Llama 3.1 405B             | El Cerebro abierto                     | Potente y transparente; ideal para personalizar e integrar en tu stack.       |
| Mistral Large 2            | El Cirujano del texto                  | Va al punto, es conciso y evita lo innecesario.                               |
| Phi‑4                      | El Compacto cumplidor                  | Ligero y económico, resuelve tareas diarias con buena calidad.                |
| DeepSeek‑V2.5              | El Ahorro con músculo                  | Rinde fuerte manteniendo costos bajos; útil para cargas intensivas.           |
| Qwen2.5                    | El Idiomas‑y‑código                    | Maneja bien varios idiomas y programación, estable y versátil.                |
| Command R+ (Cohere)        | El Bibliotecario corporativo           | Resume, busca y cita; brilla en flujos de recuperación de información.        |
| Claude Haiku               | El Resolvedor exprés                   | Responde veloz y a buen precio para altos volúmenes.                          |
| Gemini Flash               | El Relámpago multimodal                | Procesa imágenes y video en tiempo casi real con enfoque en velocidad.        |

