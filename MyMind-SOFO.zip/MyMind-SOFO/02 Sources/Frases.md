> [!Quote]- Kuma - Eidetismo - 03. El Espejo (Prod by Dano)
> La fe no mata, lo peor se hace por pasta