### 🦇 **ORIGINS (PELÍCULAS DE ORIGEN):**

- *Batman: Year One*
- *Batman: Gotham Knight*
- *Wonder Woman* (2009)
- *Green Lantern: First Flight*
- *Green Lantern: Emerald Knights*
- *Superman: Doomsday*
- *Superman vs. The Elite*
- *DC Showcase: Superman/Shazam!: The Return of Black Adam*
- *Superman/Batman: Public Enemies*
- *Superman/Batman: Apocalypse*
- *Superman: Unbound*
- *Batman: Under the Red Hood*
- *Batman: Death in the Family*
- *Justice League: The New Frontier*
- *Justice League: Crisis on Two Earths*
- *Justice League: Doom*


* * *

### 🌐 **DC ANIMATED MOVIE UNIVERSE (2013–2020):**

- *Justice League: The Flashpoint Paradox*
- *Justice League: War*
- *Son of Batman*
- *Justice League: Throne of Atlantis*
- *Batman vs. Robin*
- *Batman: Bad Blood*
- *Justice League vs. Teen Titans*
- *Justice League Dark*
- *Teen Titans: The Judas Contract*
- *Suicide Squad: Hell to Pay*
- *The Death of Superman*
- *Constantine: City of Demons*
- *Reign of the Supermen*
- *Batman: Hush*
- *Wonder Woman: Bloodlines*
- *Justice League Dark: Apokolips War*
- *Constantine: The House of Mystery

* * *

### 🚀 **TOMORROWVERSE (2020–ACTUALIDAD):**

- *Superman: Man of Tomorrow*
- *Justice Society: World War II*
- *Batman: The Long Halloween Part One*
- *Batman: The Long Halloween Part Two*
- *Green Lantern: Beware My Power*
- *Legion of Super-Heroes*
- *Justice League: Warworld*
- *Justice League: Crisis on Infinite Earths – Part One*
- *Justice League: Crisis on Infinite Earths – Part Two*
- *Justice League: Crisis on Infinite Earths – Part Three*


* * *

### 🌀 **ELSEWORLDS (REALIDADES ALTERNAS):**

- *Superman: Man of Tomorrow*
- *Justice Society: World War II*
- *Batman: The Long Halloween Part One*
- *Batman: The Long Halloween Part Two*
- *Green Lantern: Beware My Power*
- *Legion of Super-Heroes*
- *Justice League: Warworld*
- *Justice League: Crisis on Infinite Earths – Part One*
- *Justice League: Crisis on Infinite Earths – Part Two*
- *Justice League: Crisis on Infinite Earths – Part Three*

* * *

### 🌀 **DCAU (DC ANIMATED UNIVERSE / DINIVERSE):**

- *Superman: Man of Tomorrow*
- *Justice Society: World War II*
- *Batman: The Long Halloween Part One*
- *Batman: The Long Halloween Part Two*
- *Green Lantern: Beware My Power*
- *Legion of Super-Heroes*
- *Justice League: Warworld*
- *Justice League: Crisis on Infinite Earths – Part One*
- *Justice League: Crisis on Infinite Earths – Part Two*
- *Justice League: Crisis on Infinite Earths – Part Three*


* * *

### 🦾 **ARKHAMVERSE (PELÍCULA DENTRO DEL UNIVERSO DE LOS JUEGOS):**

-   _Batman: Assault on Arkham_