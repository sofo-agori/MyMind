---
status: Por leer
tags:
  - Libro
  - filosofía
Autor: AlgisA Uzdavnyz
Image: https://www.edicionesatalanta.com/wp-content/uploads/Portada-Filosofia-como-rito-de-Renacimiento.png
master folder: "[[Por leer]]"
---
