---
status: Por leer
tags:
  - Libro
  - Anarquía
  - Política
Autor: James C. Scott
Image: https://m.media-amazon.com/images/I/71sEyLU0jsL._UF894,1000_QL80_.jpg
master folder: "[[Por leer]]"
---
