---
created: 2025-08-12
tags: []
aliases: []
master folder: "[[001 Ingles]]"
---
### Presente Perfecto (Present Perfect)

El presente perfecto se utiliza para conectar el **pasado con el presente**. Se forma con el verbo auxiliar **`have`** o **`has`** seguido del **participio pasado** del verbo principal.

Se usa para hablar de:

- **Acciones que empezaron en el pasado y continúan en el presente.**
    
    - `I have lived in this city for ten years.` (He vivido en esta ciudad por diez años.) – Empecé a vivir aquí en el pasado y todavía vivo aquí.
        
- **Acciones que sucedieron en un momento no específico del pasado.**
    
    - `She has traveled to many countries.` (Ella ha viajado a muchos países.) – No sabemos cuándo lo hizo, solo que la experiencia existe.
        
- **Acciones recientes que tienen un resultado en el presente.**
    
    - `He has lost his keys.` (Él ha perdido sus llaves.) – Las perdió en el pasado y, como resultado, ahora no puede entrar a su casa.