
## Observaciones y pensamientos

- El epicureísmo es una escuela filosófica fundada por Epicuro en la Antigua Grecia, centrada en la búsqueda racional del placer (particularmente la ausencia de dolor) como clave para una vida feliz.
- Me resulta interesante cómo esta filosofía valora los placeres simples, la amistad y la tranquilidad interior, alejándose de los excesos y del miedo a los dioses o a la muerte.
- Su visión materialista del mundo y su énfasis en el autoanálisis siguen siendo sorprendentemente vigentes en la mentalidad moderna sobre el bienestar y la forma de sobrellevar los deseos.

## Personas

- Epicuro — Filósofo griego fundador de la escuela epicúrea.
- Lucrecio — Poeta romano, divulgador del epicureísmo en su obra "De rerum natura".

## Notas

- Epicuro creía que una fuente principal de ansiedad, como también ocurre con mucha gente hoy en día, era el trabajo. Trabajar era lo que había que hacer para ganar dinero, incluso si era algo mundano y sin sentido, y se volvía miserable por compañeros o jefes insoportables. [Arena](https://www.are.na/block/23440270)

## Entretenimiento

- **Libro:** "De rerum natura" — Lucrecio. Poema latino que transmite las ideas epicúreas con profundidad filosófica y literaria.
- **Documental:** "Greece: The Birth of Thought" (BBC). Incluye episodios dedicados a la filosofía epicúrea y sus rivales.
- **Conferencia:** "Epicurus on Happiness" — The School of Life. Breve video práctico y accesible sobre cómo aplicar el epicureísmo en la vida moderna.

## Etiquetas

#epicureísmo #filosofía #ataraxia #placer #historiadelpensamiento #minimalismo #bienestar
