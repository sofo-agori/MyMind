---
tags:
  - 3D
  - Blender
master folder: "[[Blender]]"
---
[Shaders - ¿Cómo evitar que la luz afecte a un objeto? - Blender Stack Exchange](https://blender.stackexchange.com/questions/65221/how-to-make-an-object-not-be-affected-by-light)

**Usa un shader Emission (Emisión)**: Conecta tu textura directamente al nodo **Emission** y al **output de material**. Así, el objeto emitirá luz de acuerdo al color original de la textura, independientemente de la iluminación de escena[

