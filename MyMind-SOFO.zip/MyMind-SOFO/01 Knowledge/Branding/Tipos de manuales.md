---
created: 2025-08-20
tags:
  - Branding
  - diseño
Image:
Url:
---
# Brand Board (Hoja de marca / tablero visual)
### 1. **Logo**

- Logo principal (versión primaria).
    
- Versiones secundarias (horizontal, vertical, isotipo solo).
    
- Variantes en color, blanco y negro, negativo.
### 2. **Paleta de colores**

- Colores primarios y secundarios.
    
- Códigos en HEX, RGB y CMYK.
    
- A veces se muestra el porcentaje de uso recomendado (ej. 70/20/10).
### 3. **Tipografía**

- Tipografía principal (para títulos).
    
- Tipografía secundaria (para textos corridos).
    
- Opcional: tipografía alternativa para acentos o subtítulos.
    
- Incluye ejemplos de uso (mayúsculas, cursivas, jerarquía).
### 4. **Elementos gráficos**

- Iconos, patrones, texturas o formas que complementen la identidad.
    
- Líneas gráficas, marcos, símbolos.
    
### 5. **Estilo fotográfico / mood**

- Muestra imágenes de referencia con el estilo que debe transmitir la marca (ej. minimalista, cálido, urbano, natural).
    
- Puede incluir filtros o ajustes sugeridos para fotos en redes.
### 6. **Aplicaciones rápidas**

- Ejemplos simples de la marca aplicada:
    
    - Tarjetas de presentación.
        
    - Papelería básica.
        
    - Post de redes sociales.
        
    - Packaging pequeño.

### Opcionales (dependiendo del diseñador o proyecto)

- **Texturas o fondos recomendados.**
    
- **Iconografía personalizada.**
    
- **Elementos prohibidos** (ej. “no estirar el logo”, “no cambiar colores”).
    
- **Microclaim o tagline** (frase corta de apoyo).



# Mini Brand Guidelines

### 1. **Introducción breve**

- Descripción rápida de la marca.
    
- Propósito o tagline (opcional).
    
- Una frase de tono inspirador o misión resumida.
### 2. **Logo**

- Logo principal.
    
- Variantes secundarias (horizontal, vertical, isotipo).
    
- Versiones a color, en negativo y monocromáticas.
    
- Usos correctos e incorrectos básicos (ej. no deformar, no cambiar colores).


### 3. **Paleta de colores**

- Colores primarios y secundarios.
    
- Códigos (HEX, RGB, CMYK, Pantone si aplica).
    
- Recomendación de uso (colores principales vs. de acento).

### 4. **Tipografía**

- Tipografía principal (para títulos).
    
- Tipografía secundaria (para párrafos).
    
- Jerarquía visual (ejemplo de cómo se ven títulos, subtítulos y cuerpo de texto).

### 5. **Elementos gráficos**

- Patrones, texturas o iconografía clave.
    
- Estilo de ilustraciones o gráficos (si la marca los utiliza).

### 6. **Fotografía y estilo visual**

- Mood fotográfico: qué tipo de imágenes se deben usar (ej. lifestyle, minimalista, urbano, natural).
    
- Ejemplos de tratamiento de fotos (con filtros o edición básica).
### 7. **Aplicaciones rápidas**

- Ejemplos básicos de la marca aplicada:
    
    - Papelería (tarjetas, hojas membreteadas).
        
    - Redes sociales (ej. un post de Instagram).
        
    - Packaging o señalética simple.

## Opcionales que suelen incluirse

- **Iconografía**: set de iconos propios o recomendados.
    
- **Lenguaje y tono**: 1–2 páginas con ejemplos de cómo hablar (ej. cercano, formal, divertido).
    
- **Plantillas básicas**: presentaciones, banners, email.


# Manual de Identidad Visual

### 1. **Introducción**

- Breve explicación de qué es la identidad visual y por qué seguir las reglas.
    
- Contexto de la marca (misión, visión o valores resumidos).

### 2. **Logo**

- Logo principal y todas sus variantes.
    
- Construcción del logo (retícula, proporciones, espacio de seguridad).
    
- Tamaños mínimos de uso.
    
- Versiones cromáticas: a color, blanco, negro, escala de grises, negativo.
    
- Usos correctos e incorrectos (ejemplos gráficos).

### 3. **Paleta cromática**

- Colores principales y secundarios.
    
- Códigos HEX, RGB, CMYK y Pantone.
    
- Reglas de combinación (qué colores conviven bien entre sí).
    
- Ejemplos de porcentajes de uso (70/20/10, etc.).

### 4. **Tipografía**

- Tipografía principal y secundaria.
    
- Jerarquía tipográfica (H1, H2, H3, párrafo, cita, botones).
    
- Alternativas para uso digital vs. impreso (ej. fuentes web seguras).
    
- Ejemplos de aplicación en titulares, párrafos y menús.

### 5. **Elementos gráficos**

- Iconografía: estilo, grosor de línea, uso de colores.
    
- Patrones, texturas y formas auxiliares.
    
- Marcos, ilustraciones o recursos complementarios.

### 6. **Estilo fotográfico**

- Definición de la línea fotográfica (ej. natural, minimalista, emocional, corporativa).
    
- Composición, encuadres y colores preferidos.
    
- Tratamiento y filtros recomendados.

### 7. **Aplicaciones básicas**

- Papelería: tarjetas de presentación, hojas membreteadas, sobres.
    
- Señalética básica.
    
- Uso digital: web, redes sociales, correo electrónico.
    
- Merchandising o packaging inicial.

### Opcionales que suelen incluirse

- **Plantillas gráficas** (presentaciones, posts, documentos).
    
- **Animación del logo** (si la marca lo usa en motion graphics).
    
- **Normas de impresión** (acabados, gramajes, materiales permitidos).
    
- **Adaptaciones para espacios físicos** (stands, rótulos, vehículos).

# Brand Guidelines
### 1. **Introducción**

- Presentación de la marca.
    
- Propósito, misión, visión y valores.
    
- Personalidad de la marca (qué la hace única).
    
- Contexto de por qué existe el manual.

### 2. **Identidad visual**

#### Logo

- Logo principal, secundarios e isotipos.
    
- Construcción, retícula, proporciones y zonas de seguridad.
    
- Tamaños mínimos.
    
- Versiones cromáticas.
    
- Usos correctos e incorrectos.

#### Colores

- Paleta primaria y secundaria.
    
- Códigos de color (HEX, RGB, CMYK, Pantone).
    
- Reglas de combinación.
    
- Porcentajes de uso recomendados.

#### Tipografía

- Fuentes principales y secundarias.
    
- Jerarquía tipográfica (titulares, subtítulos, cuerpo de texto).
    
- Alternativas web vs. impresión.

#### Elementos gráficos

- Patrones, texturas, iconografía.
    
- Estilo de ilustraciones y gráficos auxiliares.

#### Fotografía

- Mood fotográfico.
    
- Tipos de encuadre y composición.
    
- Tratamiento de color, filtros y estilo visual.
### 3. **Identidad verbal**

- Voz de marca (ej. cercana, profesional, inspiradora).
    
- Tono en diferentes contextos (redes sociales, comunicados, atención al cliente).
    
- Palabras clave y frases de apoyo.
    
- Ejemplos de cómo se debe y cómo **no** se debe comunicar.
    

### 4. **Aplicaciones**

- Papelería corporativa (tarjetas, hojas membreteadas, sobres).
    
- Material digital (posts, plantillas para redes, banners, emails).
    
- Presentaciones corporativas.
    
- Packaging.
    
- Señalética y espacios físicos.
    
- Uniformes o indumentaria (si aplica).
    
- Vehículos, stands, publicidad exterior.

### 5. **Normas de uso**

- Correcto manejo de logos en entornos digitales e impresos.
    
- Tamaños, márgenes, proporciones.
    
- Coherencia entre identidad visual y verbal.

### 6. **Inspiración / ejemplos**

- Casos de aplicación bien ejecutados.
    
- Moodboards de referencia.

## Opcionales en un Brand Guidelines

- **Motion & animación**: cómo debe moverse el logo, transiciones o estilo de motion graphics.
    
- **UI/UX**: lineamientos para sitios web o apps (botones, menús, formularios).
    
- **Brand architecture**: cómo convive la marca principal con submarcas o co-brandings.
    
- **Contenido digital**: lineamientos para videos, reels o storytelling.

# Brand Book

### 1. **Introducción inspiradora**

- La historia de la marca (origen, evolución).
    
- El propósito (por qué existe).
    
- La visión a futuro.

### 2. **Filosofía de marca**

- Misión, visión y valores contados de manera inspiracional.
    
- Manifiesto de marca (texto motivador que resume su espíritu).
    
- Personalidad de marca (con arquetipos de marca, ej. “el explorador”, “el cuidador”).

### 3. **Identidad verbal**

- Voz y tono de comunicación.
    
- Ejemplos de frases, slogans y mensajes clave.
    
- Storytelling de cómo se debe hablar en distintos escenarios.

### 4. **Identidad visual resumida**

- Logo y su significado.
    
- Colores y tipografía explicados de forma conceptual (qué transmiten, por qué se eligieron).
    
- Estilo de imágenes y mood visual.
    

_(Nota: aquí no es tan técnico como en un manual integral, sino más explicativo e inspiracional)._

### 5. **Aplicaciones inspiracionales**

- Ejemplos de campañas.
    
- Mockups de productos, tiendas, uniformes o redes sociales.
    
- Proyectos futuros donde la marca puede estar presente.

### 6. **Cultura de marca**

- Cómo deben vivir la marca los empleados y socios.
    
- Principios de atención al cliente.
    
- Ejemplos de buenas prácticas.

## 🟢 Opcionales

- Testimonios o citas de fundadores / líderes.
    
- Referencias culturales o artísticas que inspiraron la marca.
    
- Línea del tiempo de hitos importantes.
    
- Versiones extendidas con entrevistas, fotografías o material editorial.

# Corporate Brand Manual

### 1. **Fundamentos de la marca**

- Historia, propósito, misión, visión y valores.
    
- Arquetipo de marca y personalidad.
    
- Posicionamiento en el mercado.
    
- Arquitectura de marca (marca madre, submarcas, co-branding).

### 2. **Identidad visual**

- Logo: construcción, retículas, proporciones, márgenes de seguridad.
    
- Variantes: a color, monocromo, negativo, responsive logos.
    
- Usos correctos e incorrectos (extensivo).
    
- Paleta cromática completa (primaria, secundaria, acentos, tonos digitales, Pantone).
    
- Tipografías (impresión, digital, alternativas web seguras, jerarquías tipográficas).
    
- Elementos gráficos (patrones, texturas, íconos, ilustraciones).
    
- Estilo fotográfico y audiovisual (fotografía, video, animación, motion graphics).

### 3. **Identidad verbal**

- Voz de marca y cómo adaptarla según contexto (RRSS, PR, atención al cliente, comunicación interna).
    
- Tono de comunicación en distintos escenarios (formal, cercano, inspirador, técnico).
    
- Palabras clave, frases prohibidas, glosario de marca.
    
- Guía de storytelling y copywriting.
### 4. **Aplicaciones corporativas**

- Papelería completa (tarjetas, sobres, carpetas, firmas de correo).
    
- Material digital (presentaciones, redes sociales, newsletters, web).
    
- Publicidad ATL/BTL (vallas, radio, TV, medios impresos).
    
- Merchandising y packaging.
    
- Señalética, ambientación de oficinas, stands, showrooms.
    
- Uniformes e indumentaria.
    
- Vehículos corporativos.

### 5. **Comunicación integral**

- Manual de relaciones públicas.
    
- Lineamientos para comunicados de prensa.
    
- Protocolos de crisis comunicacional.
    
- Guía para voceros y entrevistas.
    
- Reglas para patrocinios, alianzas estratégicas y co-branding.

### 6. **Normas digitales**

- Lineamientos para sitios web y apps.
    
- Guía de experiencia de usuario (UI/UX).
    
- Motion graphics, transiciones, animaciones.
    
- Tratamiento audiovisual en campañas digitales.

### 7. **Cultura corporativa**

- Cómo se vive la marca internamente.
    
- Códigos de ética y conducta.
    
- Estándares de servicio al cliente.
    
- Programas de capacitación y embajadores de marca.

### 8. **Aspectos legales**

- Uso de marca registrada.
    
- Normas de licenciamiento y franquicias.
    
- Contratos de imagen y colaboraciones.
    
- Regulaciones internacionales (si aplica).
    
### Resumen:

El **Corporate Brand Manual** es el “código maestro” de la marca.  Reúne **estrategia + identidad visual + comunicación + cultura + legal**.  Se usa para **mantener coherencia global** en todas las filiales, agencias, proveedores y partners.