---
status: Por leer
tags:
  - Libro
  - Creatividad
Autor: Edward Bono
Image: https://m.media-amazon.com/images/I/81mKWNHT3yL._UF894,1000_QL80_.jpg
master folder: "[[Por leer]]"
---
