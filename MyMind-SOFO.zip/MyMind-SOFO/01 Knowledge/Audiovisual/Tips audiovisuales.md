---
tags:
  - Fotografía
  - Camara
  - Video
---
- Manten tu [[Velocidad de obturación]] al doble con respecto a las fotogramas. Por ejemplo: 25 fps - 1/50 o 1/60

## Links:
- [One reflector: 5 ways to use it](https://www.instagram.com/reel/DLSx1uqt2R4/?igsh=cTdzbThqcHdoY2Rh)
