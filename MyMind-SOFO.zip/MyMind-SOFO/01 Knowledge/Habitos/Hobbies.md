---
created: 2025-08-26
tags: []
Image:
Url:
master folder:
---
## Notes:
- [No me gusta la palabra hobby. Algo sin importancia que hace uno para entretenerse cuando no está produciendo para el sistema. No. Mis actividades, sea creación musical, lectura, entrenamiento físico y espiritual o mirar al vacío, son sagradas y tienen significación religiosa.](https://x.com/lectorplatonico/status/1902352569302671555)
