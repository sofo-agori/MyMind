---
created: 2025-08-20
tags:
  - Plugins-After
Image: "[[Overlord.png]]"
Url: https://battleaxe.co/overlord
master folder: "[[Plugins de After Effects]]"
---
Con este plugin de After Effects puedes pasar activos desde [[Illustrator]] fácilmente. Evitando así el método de sequence layers. 

![[Overlord.png]]

