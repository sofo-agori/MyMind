---
created: 2025-08-14
tags: []
aliases: []
---
Los suplementos para mis es una parte muy importante de nuestra [[Salud]]

## Links
- [Reddit - El resumen más grande de suplementos para la depresión.](https://www.reddit.com/r/Biohackers/comments/1n3vd3m/the_largest_summary_of_supplements_for_depression/)
## Notas:
- La kava puede aumentar los niveles de dopamina en el núcleo accumbens y la desmetoxiyangonina probablemente contribuya a este efecto. [Cuerpo y mente | Are.na](https://www.are.na/block/32098194)
- 