---
created: 2025-08-11
tags: []
aliases: []
---
Algunos [[trucos]] útiles. 

## Videos:
```cardlink
url: https://www.youtube.com/watch?v=B2tmgJ0HKxo
title: "10 Quick After Effects Techniques I LOVE"
description: "In this video, I showcase 10 creative After Effects techniques that you simply can't ignore, It's physically impossible*. From creating mesmerizing looping t..."
host: www.youtube.com
favicon: https://www.youtube.com/s/desktop/652cfe42/img/favicon_32x32.png
image: https://i.ytimg.com/vi/B2tmgJ0HKxo/maxresdefault.jpg
```


Links:
- [¡Gente de motion graphics! ¿Qué truquitos usan siempre para darle un toque especial? ¡Me encantaría ampliar mis herramientas diarias para evitar que las cosas se vuelvan obsoletas! : r/AfterEffects](https://www.reddit.com/r/AfterEffects/comments/1gk8ly5/motion_graphics_people_what_are_your_little/#04632ef4-8aca-48ab-8995-5b7dd243cd7f)
- 