---
created: 2025-08-25
tags: []
Image:
Url:
---
- NoFap
- Sin azúcar
- Ejercicio
- Low-carb
- No dumb-scrolling ([[01 Knowledge/Habitos/Desconexión]])

