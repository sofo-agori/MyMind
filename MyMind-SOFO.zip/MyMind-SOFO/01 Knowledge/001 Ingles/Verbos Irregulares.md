---
created: 2025-08-12
tags:
  - Ingles
aliases:
master folder: "[[001 Ingles]]"
---

|                                   |                  |               |
| --------------------------------- | ---------------- | ------------- |
| _To be (Am, are, is):_ ser, estar | _Was / Were_     | _Been_        |
| _Awake_: despertar                | _Awoke_          | _Awoken_      |
| _Become_: convertirse             | _Became_         | _Become_      |
| _Bite_: morder                    | _Bit_            | _Bitten_      |
| _Break_: romper                   | _Broke_          | _Broken_      |
| _Bring_: traer, llevar            | _Brought_        | _Brought_     |
| _Buy_: comprar                    | _Bought_         | _Bought_      |
| _Creep_: arrastrarse              | _Crept_          | _Crept_       |
| _Do/Does:_ hacer                  | _Did_            | _Done_        |
| _Drink_: beber                    | _Drank_          | _Drunk_       |
| _Eat_: comer                      | _Ate_            | _Eaten_       |
| _Feel_: sentir                    | _Felt_           | _Felt_        |
| _Fly_: volar                      | _Flew_           | _Flown_       |
| _Forget_: olvidar                 | _Forgot_         | _Forgotten_   |
| _Go_: ir                          | _Went_           | _Gone_        |
| _Have_: haber                     | _Had_            | _Had_         |
| _Hear_: oír                       | _Heard_          | _Heard_       |
| _Hit_: golpear                    | _Hit_            | _Hit_         |
| _Hurt_: herir                     | _Hurt_           | _Hurt_        |
| _Know_: saber, conocer            | _Knew_           | _Known_       |
| _Lay_: poner                      | _Laid_           | _Laid_        |
| _Learn/Learn_t: aprender          | _Learned/Learnt_ | _Learned_     |
| _Leave_: dejar                    | _Left_           | _Left_        |
| _Let_: permitir                   | _Let_            | _Let_         |
| _Lie_: echarse, acostarse         | _Lay_            | _Lain_        |
| _Light_: encender                 | _Lit/Lighted_    | _Lit/Lighted_ |
| _Lose_: perder                    | _Lost_           | _Lost_        |
| _Make_: hacer                     | _Made_           | _Made_        |
| _Pay_: pagar                      | _Paid_           | _Paid_        |
| _Put_: poner                      | _Put_            | _Put_         |
| _Read_: leer                      | _Read_           | _Read_        |
| _Ring_: llamar                    | _Rang_           | _Rung_        |
| _Run_: correr                     | _Ran_            | _Run_         |
| _Say_: decir                      | _Said_           | _Said_        |
| _See_: ver                        | _Saw_            | _Seen_        |
| _Sell_: vender                    | _Sold_           | _Sold_        |
| _Send_: enviar                    | _Sent_           | _Sent_        |
| _Set_: poner(se)                  | _Set_            | _Set_         |
| _Shake_: sacudir                  | _Shook_          | _Shaken_      |
| _Shut_: cerrar                    | _Shut_           | _Shut_        |
| _Sing_: cantar                    | _Sang_           | _Sung_        |
| _Sleep_: dormir                   | _Slept_          | _Slept_       |
| _Smell_: oler                     | _Smelt_          | _Smelt_       |
| _Spend_: gastar                   | _Spent_          | _Spent_       |
| _Steal_: robar                    | _Stole_          | _Stolen_      |
| _Strike_: golpear                 | _Struck_         | _Struck_      |
| _Swim_: nadar                     | _Swam_           | _Swum_        |
| _Teach_: enseñar                  | _Taught_         | _Taught_      |
| _Understand_: entender            | _Understood_     | _Understood_  |
| _Win_: ganar                      | _Won_            | _Won_         |