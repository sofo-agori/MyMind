Links: 
- [Akai Professional MPK Mini MK3](https://a.co/d/ioEDhTz)