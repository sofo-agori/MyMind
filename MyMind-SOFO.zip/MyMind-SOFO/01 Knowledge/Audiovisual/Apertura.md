---
tags:
  - Fotografía
  - Video
  - Camara
---
![[Apertura.jpg]]

- Una apertura grande es un número pequeño y eso significa más bookeh.
- Menos apertura (número mas grande) cuando quieres un enfoque mas general de la escena.
- Si quieres mantener un buen una apertura grande con bastante iluminación puede ser necesario un filtro ND.