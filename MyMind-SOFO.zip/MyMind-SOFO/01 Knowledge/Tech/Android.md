---
tags:
  - Android
  - Teléfonos
  - Tecnología
---
Siempre he usado android y no creo cambiarme por los momentos. Tengo un Pixel 8 Pro que en Agosto del 2025 sigue muy vigente. Quizás el año que viene piense cambiarlo pero por lo momentos es más que suficiente.

**Lista de teléfonos que he tenido:** Samsung S3, Oneplus One, Samgung j6, Oneplus Nord 2T. 

Quizás no salga de la saga Pixel, aunque siempre he soñado con un Sony Xperia.
## Links:
- [F-Droid - Free and Open Source Android App Repository](https://f-droid.org/en/) / Una especie de playstore opensource
- [LibreTube \| F-Droid - Free and Open Source Android App Repository](https://f-droid.org/en/packages/com.github.libretube/) / Youtube centrado en la privacidad 
- [Guides | Tech Lockdown](https://www.techlockdown.com/guides) - como bloquear apps 
## Devices

[CMF Watch Pro 2 \| Accessories \| Nothing \| US](https://us.nothing.tech/products/cmf-watch-pro-2?srsltid=AfmBOopNKVRTWglwH1dr-eZHOj1kVlztBqY2VIdUBnGsDA5fJqY4gEyq&Colour=Orange)-El reloj mas bonito.
[Buy Vivo X100 Ultra Flagship Best Camera Phone - Giztop](https://www.giztop.com/vivo-x100-ultra.html) - Leí que este teléfono tiene la mejor camara
[BOOX Palma 2 The Official BOOX Store](https://shop.boox.com/products/palma2) - Teléfono doble tinta muy bueno como dump phone y perfecto para lectura.


