---
tags:
  - aftereffects
  - "#efecto"
master folder: "[[Efectos]]"
---


Para lograr el estilo de la imagen en After Effects (mezcla de halftone, textura tipo cómic y vibra grainy/retro), sigue estos pasos, todos sin plugins de terceros:
![[Efecto halftone - after effects.png]]
1. Prepara tu composición

Importa tu imagen o video base a una nueva composición.

2. Agrega una textura Halftone (puntos tipo cómic)

Crea una nueva solid layer y elígela negra.

Nómbrala "Halftone".

Ve a “Efectos y preajustes” y busca el efecto CC Ball Action.

Ajusta los parámetros:

Grid Spacing: Controla el espaciado de los puntos (más chico, más densidad).

Ball Size: Controla el tamaño de los puntos.

Cambia el modo de fusión de esta capa a “Overlay” o “Multiply” según la intensidad que necesites para que los puntos se fusionen con la imagen base.

3. Añade contraste tipo cómic

Agrega una Adjustment Layer sobre tu imagen base.

Añade el efecto Curves y acentúa los negros y los blancos (en forma de S) para obtener contraste duro, tipo cómic.

Si buscas líneas aún más duras, suma el efecto Cartoon a la capa base y ajusta los “Edge Thickness” y “Shading Steps” para realzar contornos y sombras.

4. Genera el grano retro

Añade otra Adjustment Layer.

Aplica el efecto Add Grain o Noise.

Sube el “Amount” hasta que el grano sea visible pero no tape la imagen.

Puedes animar ligeramente el “Seed” para un efecto animado (grano que vibra).

5. Ajusta y experimenta

Modula opacidades de cada capa para integrar y estilizar el look.

Si buscas un color más desaturado o vintage, añade un Adjustment Layer con el efecto Tint o “Hue/Saturation”.

Consejos extra de dirección de arte digital:

Puedes recortar tus halftones con máscaras para que solo aparezcan en partes específicas de la imagen, acentuando volúmenes o protagonistas.

El fondo amarillo y los textos pueden ser creados en Illustrator y añadidos como elementos extra en After Effects.

Juega con el efecto “Roughen Edges” si quieres darle más textura rugosa a contornos.

En resumen:
Este look Halftone se hace superponiendo una textura de puntos tipo CC Ball Action, subiendo el contraste con Curves y Cartoon, agregando grano con Add Grain/Noise, y ajustando modos de fusión para lograr la estética cómic-grunge como en tu ejemplo.

#aftereffects #efecto