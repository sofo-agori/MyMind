---
created: 2025-08-19
tags:
  - Plugins-After
Image: "[[Kease-plugin.png]]"
master folder: "[[Plugins de After Effects]]"
---
Plugin de templates de curva de velocidades, fácil de usar. Esto se puede hacer nativamente en [[After Effects]], pero es menos intuitivo.

![[Kease-easing-tool-for-After-Effects-1030x502.webp]]
