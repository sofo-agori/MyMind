---
created: 2025-08-20
tags:
  - Plugins-After
Image: "[[Penpal2.gif]]"
Url: https://aescripts.com/penpal/?srsltid=AfmBOoqq7PFL4Cj3-5LaPUo1lpfAWsA8PW5qzTF_F5aQciF1FxrIBpGO
master folder: "[[Plugins de After Effects]]"
---
Penpal es un editor de vectores más poderoso que el nativo en After Effects

![[Penpal2.gif]]

]]