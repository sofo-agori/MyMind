---
status: Por leer
tags:
  - Libro
  - Creatividad
Autor: Nick Chater
Image: https://m.media-amazon.com/images/I/71rJ351RSHL._SY466_.jpg
master folder: "[[Por leer]]"
---
