---
created: 2025-09-03
tags:
  - articulo
  - Política
Image:
Url:
master folder:
---
En el mundo no existe nada más indigno que ser político. Entenderlo es todo.

El político, por definición, es alguien que busca generar hambre para que, por consecuencia, causar servidumbre. Son tipos despeinados y llenos de carencias. Cualquiera, en cualquier momento de su vida, ha señalado y aborrecido a un "servidor público".

Muchos ni estudian, simplemente un día se paran y dicen "soy capaz de tener un pueblo a mis pies", como si de un mesías se tratara. Como si ellos son especiales. Pero no, no lo son, son despojos mortales, incapaces de razonar más alla de su sucio maquiavelismo que es inherente a su "oficio". Y lo peor del caso, nadie es obligado a serlo, ni a ser politicos ni por consiguiente justificar sus fines, que por cierto, siempre es el mismo: ahogarnos.

Todos usan la buena causa como gancho, no hay ni un político en el mundo que no haya usado una falsa promesa como propulsor de sus metas. Porque son mentirosos. Porque pasarían por encima de quien tengan que pasar para obtener un puesto y desangrarnos a punta de impuestos y fiscalidad inmoral. Porque eso es lo que quieren: llenar sus bolsillos y el de sus amigos.