---
created: 2025-08-20
tags:
  - Plugins-After
Image: "[[Trim-path.gif]]"
Url: https://olaolayuan.gumroad.com/l/trimpack
master folder: "[[Plugins de After Effects]]"
---
Facilita la animación de trim path en After Effects

![[Trim-path.gif]]

