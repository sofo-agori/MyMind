---
created: 2025-08-22
tags:
  - Personal
  - filosofía
  - economia
Image:
Url:
---
El término **“barrani”** fue acuñado y popularizado por Carlos Maslatón, y significa literalmente estar fuera de todo sistema económico formal, es decir, realizar actividades económicas que no están registradas ni reguladas por el Estado. Por ejemplo, ser "barrani" es nunca haber pedido un crédito, no facturar ni tributar impuestos, y hacer transacciones en la economía informal o “en negro”.
## Notas
-[Se atribuye el término a los turcos sefaradíes que lo usan como sinónimo de "negro" y se usa para mencionar aquello que es "ilegal", "clandestino", "forastero" y como tipo de gastronomía se relaciona con la comida rápida callejera de medio oriente, ausente de toda regulación.](https://x.com/TuziJorge/status/1658976456184152066)