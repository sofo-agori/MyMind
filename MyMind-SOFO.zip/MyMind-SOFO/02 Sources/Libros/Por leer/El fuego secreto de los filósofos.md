---
status: Por leer
tags:
  - Libro
  - filosofía
Autor: Patrick Harpur
Image: https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1654624130i/16036599.jpg
master folder: "[[Por leer]]"
---
