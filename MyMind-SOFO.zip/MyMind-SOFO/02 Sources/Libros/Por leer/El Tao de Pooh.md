---
status: Por leer
tags:
  - Libro
Autor: Benjamin Hoff
Image: https://m.media-amazon.com/images/I/71Snw88OxNL._UF894,1000_QL80_.jpg
master folder: "[[Por leer]]"
---
