---
tags:
  - Tecnología
  - Programación
---
## Links:
- [Comentario de Reddit con videos para aprender programación](https://www.reddit.com/r/learnprogramming/comments/1n1varn/comment/nb1mnsj/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [Developer Roadmaps - roadmap.sh](https://roadmap.sh/) 