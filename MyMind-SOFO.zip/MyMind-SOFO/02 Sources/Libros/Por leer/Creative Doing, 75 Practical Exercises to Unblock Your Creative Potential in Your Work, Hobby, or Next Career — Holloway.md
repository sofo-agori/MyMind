---
status: Por leer
tags:
  - Libro
  - Creatividad
Autor: Herbert Lui
Image: https://m.media-amazon.com/images/I/61GI17NRsRL._UF1000,1000_QL80_.jpg
master folder: "[[Por leer]]"
---
