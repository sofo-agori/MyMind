---
created: 2025-08-20
tags: []
Image:
Url:
---
En [[After Effects]] los plugins son justos y necesarios. Incluso After prefiere incluir algunas funciones en forma de plugins que de forma nativa.