---
created: 2025-08-06
tags: []
aliases: []
---
```dataview
LIST 
FROM #aftereffects  AND #efecto 
```