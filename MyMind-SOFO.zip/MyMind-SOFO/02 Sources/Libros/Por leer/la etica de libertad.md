---
status: Por leer
tags:
  - Libro
  - Política
  - Anarquía
Autor: Murray Rothbard
Image: https://m.media-amazon.com/images/I/61whPifs-uL._UF350,350_QL50_.jpg
master folder: "[[Por leer]]"
---
