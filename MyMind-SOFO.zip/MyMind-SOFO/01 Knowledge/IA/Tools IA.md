---
created: 2025-08-23
tags: []
Image:
Url:
---
Uso más que todo Perplexity, me parece la app de IA más completa. Quizas los modelos que ofrece no son tan profundos como por separado, pero para mí es suficiente. 

Por otro lado uso ocasionalmente ChatGTP. Y tengo instalado en mi [[Android|Telefono]]
Claude, Deepseek y Gemini. Quizás cuando tenga la oportunidad usé más Gemini que chatgtp, ya que tengo un teléfono Pixel 8 Pro. 

Para cosas de audio como clonación de voz y text-to-speech[ Fish Audio](https://fish.audio/es/) y [ElevenLabs](https://elevenlabs.io/app/sign-in?redirect=%2Fapp%2Fhome) son las mejores que he visto