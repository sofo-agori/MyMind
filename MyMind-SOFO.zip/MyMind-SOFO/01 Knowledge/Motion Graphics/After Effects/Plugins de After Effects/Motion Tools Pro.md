---
created: 2025-08-20
tags:
  - Plugins-After
Image: "[[motion tools pro.jpg]]"
Url: https://motiondesign.school/products/motion-tools-pro-2025/
master folder: "[[Plugins de After Effects]]"
---
## Links: 
- [(31) Motion Tools Pro Tutorial - YouTube](https://www.youtube.com/watch?v=XDy_Q6Elmlc)

![[motion tools pro.jpg]]

Es uno de los pilares cuando se hablan de plugins de After Effects

