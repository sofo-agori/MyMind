---
created: 2025-08-12
tags: []
aliases: []
master folder: "[[001 Ingles]]"
---
**El pretérito** se utiliza para hablar de **acciones pasadas que ya terminaron**. Es un tiempo verbal completo que funciona como el verbo principal de una oración. En inglés, esto corresponde al **"past simple"**.

- **Ejemplo:** `I **ate** pizza yesterday.` (Yo **comí** pizza ayer).