---
created: 2025-08-20
tags: []
Image:
Url:
---
Me gusta jugar futbol, saltar cuerda y el senderismo. 