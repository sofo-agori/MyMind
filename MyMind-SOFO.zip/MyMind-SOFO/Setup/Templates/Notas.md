

## Observaciones y pensamientos



## Preguntas abiertas


## Enlaces internos


## Enlaces externos


## Personas


## Notas



## Conexiones y analogías



## Tareas y experimentos


## Proyectos


## Entrenamiento
