---
created: 2025-08-14
tags: []
aliases: []
---
### Mi 3 comidas favoritas
- Asado negro de mi abuela
- Reina pepiada
- Arepa de yuca con huevo revuelto y mantequilla

Tengo cerca de 10 años viviendo con un problema digestivo, medio grave. La mayoría de la comida me cae mal. Estoy en proceso de sanación. Se encontraron ulceras en mi colón. 

La alimentación junto al [[Ejercicio]] son las dos cosas más importantes para la salud.
