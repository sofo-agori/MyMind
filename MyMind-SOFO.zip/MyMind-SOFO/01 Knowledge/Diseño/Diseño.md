---
created: 2025-08-20
tags:
  - diseño
Image:
Url:
---
Soy diseñador con un enfoque multidisciplinario. El diseño es sin duda la madre de todas las ramas creativas. Todo es diseño.

- El diseño es una parte esencial del [[Branding]]