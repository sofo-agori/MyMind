---
created: 2025-08-26
tags:
  - diseño
  - tipografía
Image:
Url:
master folder:
---
## Links:
- [10 Bad Typography Habits that Scream Amateur | by Meetchopz | Medium](https://meetchopz.medium.com/10-bad-typography-habits-that-scream-amateur-8bac07f9c041) Anotaciones: [[Malos hábitos tipográficos]]
- https://wiki.wordsoftype.com/ - Enciclopedia de tipografía
- 