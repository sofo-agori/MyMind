---
created: 2025-08-12
tags: []
aliases: []
master folder: "[[001 Ingles]]"
---
**El participio pasado** no es un tiempo verbal por sí solo. Es una forma no personal del verbo que se usa para **formar tiempos compuestos** (como el presente perfecto o el pasado perfecto) o para **funcionar como adjetivo**. En inglés, se conoce como **"past participle"**.

- **Ejemplo en un tiempo compuesto (presente perfecto):** `I **have eaten** pizza.` (Yo **he comido** pizza).
    
- **Ejemplo como adjetivo:** `The **broken** window needs to be fixed.` (La ventana **rota** necesita ser reparada).