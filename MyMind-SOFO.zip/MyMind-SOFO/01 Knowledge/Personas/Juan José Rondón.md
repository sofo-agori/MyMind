---
tags:
  - Personas
  - Historia
Image: https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2D_GUC0t31mEm8MdXPoHuskRWmXt-vUm0aA&s
Descripción: Personaje histórico venezolano
---
Fue un personaje nacido en el alto llano (Guárico) que peleó en un principio con los realistas al mando de Boves. Luego pasó al bando patriótico: Primero con Páez en la batalla de quesera del medio y luego con Bolívar en la batalla del Pantano de Vargas. 

Murió por una herida en el talón que se le complicó por tétano. 

Juan José Fue uno de los personas más interesantes de la independencia venezuela. Llamado el Aquiles del Llano.