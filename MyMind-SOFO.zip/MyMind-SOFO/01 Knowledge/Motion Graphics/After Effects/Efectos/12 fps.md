---
tags:
  - aftereffects
  - efecto
master folder: "[[Efectos]]"
---
incluye que se puede renderizar x2

La animación a 12 fps se usa ampliamente porque ofrece varias ventajas clave:

- **Ahorro de tiempo y trabajo:** Solo necesitas la mitad de cuadros en comparación a 24 fps, lo que permite producir animaciones más rápido y con menos esfuerzo.
- **Estética distintiva:** El movimiento ligeramente “saltón” le da un carácter artesanal, retro o experimental, muy buscado en animaciones tradicionales, anime y estilos modernos de collage y motion graphics.
- **Más énfasis en las poses:** Fewer frames mean that every pose is more expressive and visually powerful.
- **Eficiencia técnica:** Al manejar la mitad de cuadros, los renders pueden producirse hasta el doble de rápido (x2), acelerando tanto la fase de producción como la de corrección y exportación final.
- **Tendencia contemporánea:** El look de 12 fps está muy presente en producciones actuales que buscan diferenciarse por su identidad visual y ritmo marcado.

En resumen, animar a 12 fps no solo ahorra recursos y optimiza tiempos (permitiendo renderizar x2 de rápido), sino que también imprime una personalidad y un atractivo visual muy valorados en la animación y el diseño actual[1][2][3][4].

Citas:
[1] Why is the 12fps look preferred? : r/AfterEffects - Reddit https://www.reddit.com/r/AfterEffects/comments/192diy4/why_is_the_12fps_look_preferred/
[2] What is FPS? How Frames Per Second is Used in Animation https://animationclub.school/blog/what-is-fps-or-frames-per-second/
[3] The Art of Frame Rate in Animation - Number Analytics https://www.numberanalytics.com/blog/the-art-of-frame-rate-in-animation
[4] Everything You Need to Know About Frame Rates - YouTube https://www.youtube.com/watch?v=ycle4cPbi2c
[5] 1000277682.jpeg https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/images/9369104/b56b43ff-42fd-43e4-888e-33638b2f7fc6/1000277682.jpeg
