---
created: 2025-08-22
tags:
  - Lugares
Image: "[[Ushuaia.png]]"
Url:
---
Conocer ushuaia es uno de mis más grandes [[Sueños]].

### Curiosidades:
- Es la ciudad más al sur del mundo.
- De ahi sale la mayoría de barcos hacia el artico.


![[Ushuaia.png]] 

![[Cerro Castor Ushuaia.jpg]]