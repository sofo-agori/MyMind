---
created: 2025-08-20
tags:
  - Plugins-After
Image: "[[Motion Studio.png]]"
Url: https://mtmograph.gumroad.com/l/mtmo_motion
master folder: "[[Plugins de After Effects]]"
---

## Links:
- [(31) Motion Studio — First Look - YouTube](https://www.youtube.com/watch?v=E9pPjxj1v3o)

![[Motion Studio.png]]

