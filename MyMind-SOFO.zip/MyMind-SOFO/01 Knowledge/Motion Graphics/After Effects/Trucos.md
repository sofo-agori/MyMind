---
created: 2025-09-03
tags:
  - aftereffects
Image:
Url:
master folder:
---
- Extruir obras de arte planas en 3D. Si parece aburrido pero no sé qué hacer, suelo intentar esto
- Diseñar animaciones 2D en un espacio 3D y usar movimientos de cámara para hacer paralaje para evitar tener que animar algo
- Overshoot animation
- Mi truco es que uso vídeo real siempre que sea posible. Puedes encontrar vídeos de casi cualquier cosa filmada sobre un fondo negro. Si necesito fuego, humo, filtraciones de luz, pájaros, banderas, salpicaduras de agua, lo que sea, encuentro que componer un vídeo real de algo casi siempre luce mejor que intentar hacer algo desde cero.
- Hago mucha animación 2D estilizada. Usaré el efecto Eco en capas para difuminarlas durante movimientos rápidos. Imita las técnicas de animación tradicionales y se ve mucho mejor que simplemente usar el desenfoque de movimiento, algo que a menudo parece increíblemente artificial y barato.
- Aprender a usar el editor de gráficos hará que tus cosas se vean mejor.
- Siempre agrego aberración cromática y una capa de ruido/grano encima de mis animaciones. Es un efecto sutil pero agrega mucho valor a la escena general.
- Un brillo ligero (copia borrosa de cuadro de baja opacidad), viñeta clara, desenfoque y aberración alrededor de los bordes, desenfoque de movimiento y superposiciones de grano de película.
- Uno muy pequeño pero muy útil que hago cuando trabajo con toneladas de elementos vectoriales: difuminar los bordes solo un poquito. Ayuda a difuminar los bordes y hacer que todo sea más fácil de ver. ("CC Vector Blur" o usa máscaras)
- Pegue fotogramas clave inversos. Lo agregaron hace un par de actualizaciones y simplemente recorta minutos sin esfuerzo de mis tiempos de edición.
- Saber cómo y cuándo exportar en [[12 fps]] le da una apariencia genial.

Extraído de: https://www.reddit.com/r/AfterEffects/comments/1gk8ly5/motion_graphics_people_what_are_your_little/#04632ef4-8aca-48ab-8995-5b7dd243cd7f
