Cada vez que giro el acetato no cocino bullshit, carmy berzato,
peleando con Pete Castiglioni, cada vez que me nombran hay desacato.

Te gustan los patos, Tony Soprano

