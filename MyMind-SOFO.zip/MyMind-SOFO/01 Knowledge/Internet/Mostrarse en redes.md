---
created: 2025-08-26
tags:
  - Personal
  - Internet
Image:
Url:
master folder:
---
## Notas:
- [La mayoría de nosotros anhelamos ofrecer al mundo algo de calidad, algo que el mundo considere bueno o importante. Y ese es el verdadero enemigo, porque no depende de nosotros si lo que hacemos es bueno o no, y si algo nos ha enseñado la historia, es que el mundo es un crítico extremadamente poco fiable. La despersonalización es otra forma de decirlo. No todo tiene que ser personal; de hecho, aunque nuestro trabajo creativo se base en nuestras experiencias vividas, sigue siendo simplemente nuestro trabajo. Lo que creamos no es un reflejo completo de quiénes somos; debemos evitar la trampa de sobreidentificarnos con nuestro trabajo.](https://ehandbook.com/3-simple-habits-for-better-creativity-904229f0c6cf)