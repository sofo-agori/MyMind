---
created: 2025-08-20
tags:
  - Plugins-After
Image: "[[Shade-plugin.png]]"
Url: https://davideboscolo.com/product/shade-color-manager-for-after-effects/
master folder: "[[Plugins de After Effects]]"
---
Crea paleta de colores en After Effects

![[Shade-plugin.png]]
