---
master folder: "[[001 Ingles]]"
---
**Envío**: Shipping / Delivery
**Peso:** Weight
Gotas: Drops
Make


| Palabra | traduccion | pasado                          |
| ------- | ---------- | ------------------------------- |
| Make    | hacer      | made                            |
| Run     | Correr     | Ran                             |
| Drink   | Tomar      | Drank                           |
| See     | Ver        | Saw                             |
| Read    | Leer       | Read / se pronuncia<br>distinto |
|         |            |                                 |

