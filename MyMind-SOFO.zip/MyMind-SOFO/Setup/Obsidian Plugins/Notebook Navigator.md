
[I missed Apple Notes, so I created it as an Obsidian plugin : r/ObsidianMD](https://www.reddit.com/r/ObsidianMD/comments/1l79i9e/i_missed_apple_notes_so_i_created_it_as_an/)

[GitHub - johansan/notebook-navigator: Replace the default file explorer in Obsidian with a clean two-pane interface featuring folder tree, tag browsing, file previews, keyboard navigation, drag-and-drop, pinned notes, and customizable display options.](https://github.com/johansan/notebook-navigator)

> [!NOTE]
> # Features
> 
> - 📁 **Two-pane interface:** Clean layout with folder tree on the left, file list on the right
>     
> - 🏷️ **Hierarchical tag browsing:** View and navigate all your tags in a tree structure with nested tags support
>     
> - 🔍 **Smart file previews:** Shows content preview with date and first lines of text
>     
> - 🖼️ **Feature images:** Display thumbnail images from frontmatter properties
>     
> - 📌 **Pin important notes:** Keep frequently accessed notes at the top of any folder
>     
> - ⌨️ **Full keyboard navigation:** Navigate entirely with arrow keys, Tab and Shift+Tab
>     
> - 🔄 **Multiple sort options:** Sort by date modified, date created, or title
>     
> - 📅 **Date grouping:** Automatically group files by Today, Yesterday, Previous 7 days, etc.
>     
> - 🎯 **Drag and drop:** Move files and folders with intuitive drag and drop
>     
> - 🎨 **Customizable appearance:** Adjust date formats
>     
> - 🌓 **Dark mode support:** Fully integrated with Obsidian's theme system
>     
> - 📱 **Mobile support:** Full functionality on iOS and Android devices with touch gestures
>     
> - ↔️ **Resizable panes:** Drag the divider to adjust folder/file pane widths
>     
> - 🚀 **Auto-reveal:** Automatically reveal files when opened from search or links