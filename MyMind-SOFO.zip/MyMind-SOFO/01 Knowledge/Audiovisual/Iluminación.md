

## Links:
- [Lighting changes everything! From flat to cinematic, here's how different setups shape your image.](https://www.instagram.com/reel/DH80WsBCSaZ/?igsh=cHE1dnp4ZGNzZm9n)
- [¡2(!) luces + un reflector + cualquier cámara/teléfono. ¡ESO ES TODO! Podría ser un vídeo de belleza, una reseña tecnológica, un canal de ciencia... ¡LO QUE SEA! ¡VAMOS!](https://www.instagram.com/reel/DLXPzRbBEgS/?igsh=MTNpemliNHh5bmZuYg==)
- [Instagram: Tipos de softbox](https://www.instagram.com/reel/DKJ4RqjS8TH/?igsh=MXhsMng1eWh4cXJt)
- [El momento en que te das cuenta de que una buena iluminación es mejor que una cámara de 5000 dólares.](https://www.instagram.com/reel/DNd4T1_xcYg/?igsh=MXU4MHYxYXV6Znh4YQ==)
- 