---
created: 2025-08-20
tags:
  - Plugins-After
Image: "[[Align Pro.png]]"
Url: https://intro-hd.net/aescripts-align-pro-1-1-win-mac/
master folder: "[[Plugins de After Effects]]"
---
Potencia el panel **Align** de After Effects

![[Align Pro.png]]


