---
status: Por leer
tags:
  - Libro
  - filosofía
Autor: Antonio Escohotado
Image: https://m.media-amazon.com/images/I/81O2cSrI24L._UF350,350_QL50_.jpg
master folder: "[[Por leer]]"
---
