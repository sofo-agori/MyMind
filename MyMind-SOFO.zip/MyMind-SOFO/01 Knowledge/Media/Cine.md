---
created: 2025-08-26
tags: []
Image:
Url:
master folder:
---
Notes:
- [Tarkovsky y Kubrick parecen cercanos pero son antípodas. Ambos fotógrafos, ambos con obras breves, pero lo que en Kubrick es fáustico, caótico y secretamente perverso, horizontal, en Tarkovsky es angélico, ortodoxo, monacal, vertical. Andrei es el último santo de la modernidad.](https://x.com/elanarca/status/1837091340129075308#1413d752-25a5-44ce-b538-d581473b1ab2)
- 