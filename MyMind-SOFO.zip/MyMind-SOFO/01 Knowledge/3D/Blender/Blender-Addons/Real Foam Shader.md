---
created: 2025-09-04
tags: []
Image: https://public-files.gumroad.com/hcqj0q7iqmlu3421li3ish92e7on
Url: https://sergidis.gumroad.com/l/real-foam
master folder:
---
Es un material procedimental que permite crear diferentes tipos de espuma de forma sencilla sin necesidad de utilizar complejos sistemas de partículas o mapas de textura, basta con un único nodo maestro.

![[Real Foam Shader.png]]