---
created: 2025-08-11
tags: []
aliases: []
master folder:
---

## Esenciales
- [[Blender Shortcuts]]
- [[Principled BSDF]]
## How To
- [[Material sin que le afecte la iluminación]]
## Links:

