## Observaciones
- Saber de plantas es uno de mis pendientes. Me gustan, pero aún no sé admirar tanto su belleza.
- De las plantas lo que más me gusta es cuando se mezcla con la [[Arquitectura]], sobre todo el [[Eco-brutalismo]]

---

## Notas externas

- En realidad, las plantas nos cultivan, dándonos oxígeno diariamente, hasta que finalmente todos nos descomponemos y pueden consumirnos - [Plants plants plants | Are.na](https://www.are.na/block/5864822)

## Links:
- [Plant Guides](https://howmanyplants.com/plant-guides) -  recurso dedicado a ofrecer guías completas sobre el cuidado de plantas de interior.
 