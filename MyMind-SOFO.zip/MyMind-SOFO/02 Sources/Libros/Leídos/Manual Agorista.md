---
status: "[[!Leídos]]"
Image: https://books.google.co.ve/books/publisher/content?id=o8xUEQAAQBAJ&pg=PP1&img=1&zoom=3&hl=en&sig=ACfU3U0gnBBI-4LyxAP9YfurXHUpo9OzCg&w=1280
Autor: Samuel Edward Konkin III
master folder: "[[Leídos]]"
---

Libro introductorio sobre el [[Agorismo]]



> Recuerda siempre que el agorismo integra teoría y 
> práctica. La teoría sin práctica es un juego de niños. En 
> cambio, si se toma en serio, conduce hacia una abstracción 
> de la realidad, el misticismo y la locura. La práctica sin 
> teoría es robótica; tomada en serio, lleva a labrar suelo 
> estéril y a ir a trabajar a fábricas cerradas.

> Considera un caso particularmente patológico en los 
> EEUU. Si cobras por tu producto un precio mayor que el 
> de tus competidores, esto es considerado como una 
> evidencia ante la Ley Sherman Antitrust de que tienes un 
> monopolio, por lo que podrían presentarse cargos contra 
> ti. Surge el mismo problema si cobras el mismo precio; 
> esto es considerado como evidencia de cartel y tanto tú 
> como tus competidores podéis ser multados. Por último, si 
> cobras menos que tus competidores, estás violando las 
> leyes de “comercio justo” de la mayoría de los estados y te 
> expones a ser arrestado y multado. Es imposible obedecer 
> todas las regulaciones.

>  La Economía es una ciencia triste. Aquellos que comprenden ciertos conceptos económicos sacan de ellos un provecho ostentoso. La economía es una herramienta que las corporaciones y los gobiernos suelen utilizar para controlar la sociedad. Aquellos que comprenden ciertos conceptos económicos tienen gobiernos derrotados que rechazan afrontar los mismos conceptos. La Economía es una carrera universitaria sin sentido. Los especuladores que entienden los conceptos generan millones de dólares y salvan a otros de la ruina financiera. Aquí está nuestro problema: todas las afirmaciones formuladas arriba son ciertas.


> Sorpresa. Cuanto más controles y tasas impone un Estado a su gente, más esfuerzos realizarán éstos por evadirlos y oponerse a ellos.

> La sociedad reconoce a los objetores de conciencia: al religioso que disiente de las leyes que su deidad le prohíbe obedecer, al hombre o la mujer que sigue la ley de Dios o la naturaleza, en oposición al monopolio prevalente en la sociedad. Dado que preferirían morir a someterse, una sociedad que quiera evitar la represión salvaje eximirá a muchos objetores.

> Los soviets llamaban a los bienes de la contraeconomía bienes de “mano izquierda” o nalevo, y coexistían en la misma planta líneas de producción enteras de bienes nalevo junto con las inconexas líneas de producción estatales. 

> La imposición del Estado de la moral de algunas personas sobre otras conduce al contrabando de Biblias en estadoa ateistas y de revistas pornografica en estadoa reiligiosos  

> La regla básica de la contraeconomía es intercambiar riesgo por beneficio. Habiéndolo hecho, uno naturalmente (actuando con vistas a eliminar el malestar) intenta reducir los riesgos. Si reduces los tuyos mientras otros continúan asumiendo los riesgos mayores, naturalmente desplazas a tus competidores y sobrevives más tiempo. Y te beneficias. 

> La premisa básica del pensamiento agorista es que la contraeconomía ha fallado en su intento de crear una sociedad libre, al carecer de una estructura moral que sólo un sistema filosófico completo puede ofrecer.

>  Cristianos, taoístas, objetivistas y paganos recorren rutas diferentes para alcanzar un código moral común: el principio de coacción, o la intimidación con violencia, es inmoral. Éste es el principio libertario.

>  Los estatistas abogan por crear un criminal superior, un gran monstruo institucional que aterrorice a casi todos, culpables o inocentes, y los conduzca a la sumisión. Esta organización extraerá alguna forma de aceptación de sus  ciudadanos” e incluso les saqueará a voluntad (fiscalidad).

> El libro de Samuel, en el Antiguo Testamento, describe al profeta anarquista Samuel intentando convencer a los israelitas de que en realidad ellos no querían un rey, pero acabó dándose por vencido. 

> Y esos asaltadores bárbaros institucionalizaron el saqueo (fiscalidad), el asesinato (ejecución y guerra), e incluso la violación (droit de seigneur, por ejemplo). Tomaron el control de las carreteras para saquear las caravanas (peajes, tarifas), suprimieron todas las bandas criminales por la suya (policía), y establecieron sus propias iglesias, escuelas, juzgados e incluso filósofos, trovadores y artistas que trabajaban en sus cortes reales. 
> Así nació el Estado. 

> Entonces incluso a los campesinos y a los trabajadores se les permitió saquear a sus compañeros mercantes, granjeros y trabajadores. A eso se le llamó democracia. Se permitió que surgieran grupos que organizaran pugnas sobre quién debería robar a quién (aunque una élite de burócratas y hombres de negocio millonarios se perpetuaron, sin importar quién saliera electo) y así se formaron los partidos políticos.

>  En un Estado, es probable que la policía te arreste por algún crimen que carece de víctima. No hay “crímenes” sin víctima en el ágora.

> El camino desde aquí hasta el ágora se convierte ahora en deslumbrantemente obvio. Cuanta más gente rechaza las mistificaciones del Estado —nacionalismo, pseudoeconomía, falsas amenazas y promesas políticas traicioneras—, la contraeconomía crece tanto vertical como horizontalmente. Horizontalmente, abarca a más y más personas que desvían más y más parte de su actividad hacia lo contraeconómico; verticalmente, significa que nuevas estructuras (empresas y servicios) crecen específicamente para servir a la contraeconomía (enlaces comunicativos fiables, árbitros, seguros para actividades específicamente “ilegales”, técnicas precoces de protección tecnológica, e incluso guardias y protectores). 

> El Estado tiene armas de fuego y hombres para usarlas. Como hemos visto, sin embargo, no sólo puede fracasar en coaccionar a una mayoría rebelde, sino que tampoco puede frenar una minoría empresarial de mercaderes negros y otros contraeconomistas. **El Estado debe ser derrotado en la mente de cada persona.**
> 


> Recuerda, un agorista es el que vive contraeconómicamente sin remordimientos por sus heroicas acciones del día a día, con la vieja moral libertaria de no violentar jamás a ninguna persona o propiedad. No disponemos de ninguna “tarjeta de socio” para embaucarte; agorista es quien vive el agorismo. No acepta falsificaciones. 
> Hay agoristas que “lo intentan”. Hay, por supuesto, mentirosos que reivindican ser cualquier cosa. Como dijo Yoda brevemente, «Hazlo o no lo hagas, pero no lo intentes».  Eso es el agorismo. 